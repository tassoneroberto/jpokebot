package app;

import com.pokegoapi.api.PokemonGo;
import com.pokegoapi.api.player.PlayerProfile.Currency;
import com.pokegoapi.exceptions.LoginFailedException;
import com.pokegoapi.exceptions.RemoteServerException;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.HashMap;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.ScrollPaneConstants;
import javax.swing.text.DefaultCaret;

public class FrameBot extends JFrame {

  private static final long serialVersionUID = 1L;

  private JPanel panelMain, panelPlayer, panelInfo, panelCommands, panelDisplay;
  private JLabel labelUserInfo;
  protected JButton buttonInventory, buttonPokebank, buttonStats, buttonStart, buttonStop, buttonOptions;
  private JTextArea textAreaDisplay;
  private FramePlayerInfo frameInfo;
  private FramePokebank framePokebank;
  private FrameInventory frameInventory;
  private FrameOptions frameOptions;
  private final int mButtonWidth = 100;
  private PokemonGo go;
  protected HashMap<Integer, String[]> moveset;

  public FrameBot(PokemonGo go, double latitude, double longitude) {
    this.go = go;
    go.setLatitude(latitude);
    go.setLongitude(longitude);
    go.setAltitude(17);
    this.setTitle("jPokéBot" + " v" + Bot.VERSION);
    int width = 540;
    int height = 460;
    this.setSize(width, height);
    this.setLocationRelativeTo(null);
    this.setLayout(null);
    this.setResizable(false);
    this.setDefaultCloseOperation(EXIT_ON_CLOSE);

    panelMain = new JPanel(null);
    this.add(panelMain);
    panelMain.setBounds(0, 0, width, height);

    // DISPLAY PANEL
    panelDisplay = new JPanel(null);
    panelDisplay.setBorder(
      BorderFactory.createTitledBorder(
        BorderFactory.createEtchedBorder(),
        "Display"
      )
    );
    panelDisplay.setBounds(10, 130, width - 20, 300);
    // TextArea Display
    textAreaDisplay = new JTextArea();
    textAreaDisplay.setEditable(false);
    JScrollPane scroll = new JScrollPane(textAreaDisplay);
    scroll.setVerticalScrollBarPolicy(
      ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS
    );
    panelDisplay.add(scroll);
    scroll.setBounds(10, 20, width - 40, 300 - 30);
    DefaultCaret caret = (DefaultCaret) textAreaDisplay.getCaret();
    caret.setUpdatePolicy(DefaultCaret.ALWAYS_UPDATE);

    textAreaDisplay.addMouseListener(
      new MouseAdapter() {
        public void mousePressed(MouseEvent me) {
          // FIXME sutoscroll
        }
      }
    );

    Bot bot = new Bot(go, textAreaDisplay, this);

    // PLAYER PANEL
    panelPlayer = new JPanel(null);
    panelPlayer.setBorder(
      BorderFactory.createTitledBorder(
        BorderFactory.createEtchedBorder(),
        "Player"
      )
    );
    panelPlayer.setBounds(10, 10, width / 2 - 80, 115);
    // User label
    labelUserInfo = new JLabel("");
    updateUserInfo();
    panelPlayer.add(labelUserInfo);
    labelUserInfo.setBounds(10, 12, 200, 100);

    // INFO PANEL
    panelInfo = new JPanel(null);
    panelInfo.setBorder(
      BorderFactory.createTitledBorder(
        BorderFactory.createEtchedBorder(),
        "Info"
      )
    );
    panelInfo.setBounds(width / 2 - 70, 10, width / 2 + 60, 55);
    // Stats button
    buttonStats = new JButton("Stats");
    panelInfo.add(buttonStats);
    buttonStats.setBounds(10, 20, mButtonWidth, 20);
    buttonStats.addActionListener(
      new ActionListener() {
        public void actionPerformed(ActionEvent e) {
          frameInfo.refresh();
          frameInfo.setVisible(true);
        }
      }
    );
    // Pokebank button
    buttonPokebank = new JButton("Pokébank");
    panelInfo.add(buttonPokebank);
    buttonPokebank.setBounds(mButtonWidth + 15, 20, mButtonWidth, 20);
    buttonPokebank.addActionListener(
      new ActionListener() {
        public void actionPerformed(ActionEvent e) {
          framePokebank.refresh();
          framePokebank.setVisible(true);
        }
      }
    );
    // Inventory button
    buttonInventory = new JButton("Inventory");
    panelInfo.add(buttonInventory);
    buttonInventory.setBounds(mButtonWidth * 2 + 20, 20, mButtonWidth, 20);
    buttonInventory.addActionListener(
      new ActionListener() {
        public void actionPerformed(ActionEvent e) {
          frameInventory.refresh();
          frameInventory.setVisible(true);
        }
      }
    );

    // BOT COMMANDS PANEL
    panelCommands = new JPanel(null);
    panelCommands.setBorder(
      BorderFactory.createTitledBorder(
        BorderFactory.createEtchedBorder(),
        "Bot commands"
      )
    );
    panelCommands.setBounds(width / 2 - 70, 70, width / 2 + 60, 55);
    // Start button
    buttonStart = new JButton("Start");
    panelCommands.add(buttonStart);
    buttonStart.setBounds(10, 20, mButtonWidth, 20);
    buttonStart.addActionListener(
      new ActionListener() {
        public void actionPerformed(ActionEvent e) {
          bot.startBot();
          go.setLatitude(latitude);
          go.setLongitude(longitude);
          buttonStop.setEnabled(true);
          buttonStart.setEnabled(false);
          buttonOptions.setEnabled(false);
          frameOptions.setVisible(false);
        }
      }
    );
    // Stop button
    buttonStop = new JButton("Stop");
    panelCommands.add(buttonStop);
    buttonStop.setEnabled(false);
    buttonStop.setBounds(mButtonWidth + 15, 20, mButtonWidth, 20);
    buttonStop.addActionListener(
      new ActionListener() {
        public void actionPerformed(ActionEvent e) {
          bot.stopBot();
          buttonStop.setEnabled(false);
          buttonStart.setEnabled(true);
          buttonOptions.setEnabled(true);
        }
      }
    );
    // Options button
    buttonOptions = new JButton("Options");
    panelCommands.add(buttonOptions);
    buttonOptions.setBounds(mButtonWidth * 2 + 20, 20, mButtonWidth, 20);
    buttonOptions.addActionListener(
      new ActionListener() {
        public void actionPerformed(ActionEvent e) {
          frameOptions.setVisible(true);
        }
      }
    );

    panelMain.add(panelPlayer);
    panelMain.add(panelInfo);
    panelMain.add(panelCommands);
    panelMain.add(panelDisplay);

    frameInfo = new FramePlayerInfo(go);
    framePokebank = new FramePokebank(go);
    frameInventory = new FrameInventory(go);
    frameOptions = new FrameOptions(go);

    loadDefaultSettingsRecycle();
    loadDefaultSettingsGeneral();
    loadDefaultSettingsPokemonCatch();
    loadDefaultSettingsPokemonTransfer();
    loadDefaultSettingsPokemonRename();
  }

  public void updateUserInfo() {
    try {
      go.getInventories().updateInventories();
      go.getPlayerProfile().updateProfile();
    } catch (LoginFailedException e) {
      e.printStackTrace();
    } catch (RemoteServerException e) {
      e.printStackTrace();
    }
    labelUserInfo.setText(
      "<html><body>Name: " +
      go.getPlayerProfile().getPlayerData().getUsername() +
      "<br>Level: " +
      go.getPlayerProfile().getStats().getLevel() +
      "<br>XP next level: " +
      (
        go.getPlayerProfile().getStats().getNextLevelXp() -
        go.getPlayerProfile().getStats().getExperience()
      ) +
      "<br>Pokébank: " +
      go.getInventories().getPokebank().getPokemons().size() +
      "/" +
      go.getPlayerProfile().getPlayerData().getMaxPokemonStorage() +
      "<br>Inventory: " +
      go.getInventories().getItemBag().getItemsCount() +
      "/" +
      go.getPlayerProfile().getPlayerData().getMaxItemStorage() +
      "<br>Stardust: " +
      go.getPlayerProfile().getCurrency(Currency.STARDUST) +
      "</body></html>"
    );
    this.repaint();
  }

  public void loadDefaultSettingsRecycle() {
    BufferedReader br = new BufferedReader(
      new InputStreamReader(
        getClass()
          .getResourceAsStream("/jPokéBotResources/settingsItemRecycle.txt")
      )
    );
    frameOptions.recycleType = "Balanced";
    boolean firstStart = false;
    String line;
    try {
      while ((line = br.readLine()) != null) {
        String[] info = line.split("=");
        if (info.length == 2 && !info[1].equals("")) {
          if (info[0].equals("active")) if (
            info[1].equals("true")
          ) frameOptions.cActiveRecycle.setSelected(
            true
          ); else frameOptions.cActiveRecycle.setSelected(false); else if (
            info[0].equals("defaultConfig")
          ) {
            frameOptions.recycleType = info[1];
          } else if (info[0].equals("firstStart")) {
            if (info[1].equals("true")) {
              firstStart = true;
              frameOptions.chooseDefaultRecycle.setSelectedItem("Balanced");
              frameOptions.setDefaultRecycle(go);
            }
          } else if (info[0].equals("autoUpdate")) if (
            info[1].equals("true")
          ) frameOptions.autoUpdate.setSelected(
            true
          ); else frameOptions.autoUpdate.setSelected(false); else if (
            info[0].equals("recycleWhenFull")
          ) if (
            info[1].equals("true")
          ) frameOptions.cRecycleWhenFull.setSelected(
            true
          ); else frameOptions.cRecycleWhenFull.setSelected(false); else if (
            info[0].equals("keepMasterball")
          ) if (info[1].equals("true")) {
            frameOptions.cKeepMasterball.setSelected(true);
          } else frameOptions.cKeepMasterball.setSelected(false); else if (
            info[0].equals("keepIncense")
          ) if (info[1].equals("true")) frameOptions.cKeepIncense.setSelected(
            true
          ); else frameOptions.cKeepIncense.setSelected(false); else if (
            info[0].equals("keepTroyDisk")
          ) if (info[1].equals("true")) frameOptions.cKeepTroyDisk.setSelected(
            true
          ); else frameOptions.cKeepTroyDisk.setSelected(false); else if (
            info[0].equals("keepLuckyEgg")
          ) if (info[1].equals("true")) frameOptions.cKeepLuckyEgg.setSelected(
            true
          ); else frameOptions.cKeepLuckyEgg.setSelected(false); else if (
            info[0].equals("pokeball")
          ) frameOptions.fPokeball.setText(info[1]); else if (
            info[0].equals("megaball")
          ) frameOptions.fMegaball.setText(info[1]); else if (
            info[0].equals("ultraball")
          ) frameOptions.fUltraball.setText(info[1]); else if (
            info[0].equals("masterball")
          ) {
            if (info[1].equals("infinity")) frameOptions.fMasterball.setText(
              "∞"
            ); else frameOptions.fMasterball.setText(info[1]);
          } else if (info[0].equals("potion")) frameOptions.fPotion.setText(
            info[1]
          ); else if (
            info[0].equals("superpotion")
          ) frameOptions.fSuperPotion.setText(info[1]); else if (
            info[0].equals("hyperpotion")
          ) frameOptions.fHyperPotion.setText(info[1]); else if (
            info[0].equals("maxpotion")
          ) frameOptions.fMaxPotion.setText(info[1]); else if (
            info[0].equals("revive")
          ) frameOptions.fRevive.setText(info[1]); else if (
            info[0].equals("maxrevive")
          ) frameOptions.fMaxRevive.setText(info[1]); else if (
            info[0].equals("razzberry")
          ) frameOptions.fRazzberry.setText(info[1]); else if (
            info[0].equals("incense")
          ) if (info[1].equals("infinity")) frameOptions.fIncense.setText(
            "∞"
          ); else frameOptions.fIncense.setText(info[1]); else if (
            info[0].equals("troydisk")
          ) if (info[1].equals("infinity")) frameOptions.fTroyDisk.setText(
            "∞"
          ); else frameOptions.fTroyDisk.setText(info[1]); else if (
            info[0].equals("luckyegg")
          ) if (info[1].equals("infinity")) frameOptions.fLuckyEgg.setText(
            "∞"
          ); else frameOptions.fLuckyEgg.setText(info[1]);
        }
      }
    } catch (IOException e) {
      e.printStackTrace();
    }
    frameOptions.chooseDefaultRecycle.setSelectedItem(frameOptions.recycleType);
    if (!frameOptions.recycleType.equals("Custom")) {
      frameOptions.autoUpdate.setEnabled(true);
      frameOptions.setDefaultRecycle(go);
    }
    if (firstStart) {
      frameOptions.setDefaultRecycle(go);
      frameOptions.saveSettings();
    }
  }

  public void loadDefaultSettingsGeneral() {
    BufferedReader br = new BufferedReader(
      new InputStreamReader(
        getClass().getResourceAsStream("/jPokéBotResources/settingsGeneral.txt")
      )
    );
    String line;
    try {
      while ((line = br.readLine()) != null) {
        String[] info = line.split("=");
        if (info.length == 2 && !info[1].equals("")) {
          if (info[0].equals("width")) {
            frameOptions.bWidth.setSelectedItem(info[1]);
          } else if (
            info[0].equals("timeToCollect")
          ) frameOptions.fTimeToCollect.setText(info[1]); else if (
            info[0].equals("rescanTimeOut")
          ) frameOptions.fRescanTimeOut.setText(info[1]); else if (
            info[0].equals("speed")
          ) frameOptions.fSpeed.setText(info[1]); else if (
            info[0].equals("getLevelReward")
          ) if (
            info[1].equals("true")
          ) frameOptions.cGetLevelReward.setSelected(true); else if (
            info[1].equals("trfalseue")
          ) frameOptions.cGetLevelReward.setSelected(false);
        }
      }
    } catch (IOException e) {
      e.printStackTrace();
    }
  }

  public void loadDefaultSettingsPokemonTransfer() {
    BufferedReader br = new BufferedReader(
      new InputStreamReader(
        getClass()
          .getResourceAsStream("/jPokéBotResources/settingsTransfer.txt")
      )
    );
    String line;
    try {
      while ((line = br.readLine()) != null) {
        String[] info = line.split("=");
        if (info.length == 2 && !info[1].equals("")) {
          if (info[0].equals("active")) if (info[1].equals("true")) {
            frameOptions.cActiveTransfer.setSelected(true);
            frameOptions.enablePokemonTransferButtons();
          } else {
            frameOptions.cActiveTransfer.setSelected(false);
            frameOptions.disablePokemonTransferButtons();
          } else if (info[0].equals("minCP")) frameOptions.fMinCP.setText(
            info[1]
          ); else if (info[0].equals("minIV")) frameOptions.fMinIV.setText(
            info[1]
          ); else if (info[0].equals("keepMinCP")) if (info[1].equals("true")) {
            frameOptions.cMinCP.setSelected(true);
            frameOptions.fMinCP.setEnabled(true);
          } else {
            frameOptions.cMinCP.setSelected(false);
            frameOptions.fMinCP.setEnabled(false);
          } else if (info[0].equals("keepMinIV")) if (info[1].equals("true")) {
            frameOptions.cMinIV.setSelected(true);
            frameOptions.fMinIV.setEnabled(true);
          } else {
            frameOptions.cMinIV.setSelected(false);
            frameOptions.fMinIV.setEnabled(false);
          } else if (info[0].equals("keepLegendaries")) if (
            info[1].equals("true")
          ) frameOptions.cLegendary.setSelected(true); else {
            frameOptions.cLegendary.setSelected(false);
          } else if (info[0].equals("keepFavorites")) if (
            info[1].equals("true")
          ) frameOptions.cFavorite.setSelected(true); else {
            frameOptions.cFavorite.setSelected(false);
          } else if (info[0].equals("keepPerfectMoves")) if (
            info[1].equals("true")
          ) frameOptions.cPerfectMoves.setSelected(true); else {
            frameOptions.cPerfectMoves.setSelected(false);
          } else if (info[0].equals("activeSmartTransfer")) if (
            info[1].equals("true")
          ) {
            frameOptions.cActiveSmartTransfer.setSelected(true);
            if (
              frameOptions.prioritySlider.getValue() != 50
            ) frameOptions.balancePriority.setEnabled(true);
            frameOptions.prioritySlider.setEnabled(true);
            frameOptions.fMinAverage.setEnabled(true);
          } else {
            frameOptions.cActiveSmartTransfer.setSelected(false);
            frameOptions.balancePriority.setEnabled(false);
            frameOptions.prioritySlider.setEnabled(false);
            frameOptions.fMinAverage.setEnabled(false);
          } else if (info[0].equals("priority")) {
            frameOptions.prioritySlider.setValue(Integer.parseInt(info[1]));
            frameOptions.lPriority.setText(
              "Set your priority: [IV " +
              frameOptions.prioritySlider.getValue() +
              "%] [CP " +
              (100 - frameOptions.prioritySlider.getValue()) +
              "%]"
            );
          } else if (
            info[0].equals("minAverage")
          ) frameOptions.fMinAverage.setText(info[1]); else if (
            info[0].equals("maxDuplicate")
          ) frameOptions.fMaxDuplicate.setText(info[1]);
        }
      }
    } catch (IOException e) {
      e.printStackTrace();
    }

    loadMoveset();
  }

  public void loadMoveset() {
    moveset = new HashMap<Integer, String[]>();
    BufferedReader br = new BufferedReader(
      new InputStreamReader(
        getClass().getResourceAsStream("/jPokéBotResources/moveset.txt")
      )
    );
    String line;
    try {
      while ((line = br.readLine()) != null) {
        String[] split = line.split("\\|");
        String[] moves = new String[2];
        moves[0] = split[2].toUpperCase().replaceAll(" ", "_") + "_FAST";
        moves[1] = split[3].toUpperCase().replaceAll(" ", "_");
        moveset.put(Integer.parseInt(split[0]), moves);
      }
    } catch (IOException e) {
      e.printStackTrace();
    }
  }

  public void loadDefaultSettingsPokemonCatch() {
    BufferedReader br = new BufferedReader(
      new InputStreamReader(
        getClass()
          .getResourceAsStream("/jPokéBotResources/settingsPokemonCatch.txt")
      )
    );
    String line;
    try {
      while ((line = br.readLine()) != null) {
        String[] info = line.split("=");
        if (info.length == 2 && !info[1].equals("")) {
          if (info[0].equals("active")) if (
            info[1].equals("true")
          ) frameOptions.cActiveCatch.setSelected(
            true
          ); else frameOptions.cActiveCatch.setSelected(false); else if (
            info[0].equals("timeOutCatch")
          ) frameOptions.fTimeOutCatch.setText(info[1]);
          if (info[0].equals("useBerry")) if (
            info[1].equals("true")
          ) frameOptions.cUseBerry.setSelected(
            true
          ); else frameOptions.cUseBerry.setSelected(false);
          if (info[0].equals("useMasterballOnLegendary")) if (
            info[1].equals("true")
          ) frameOptions.cUseMasterballOnLegendary.setSelected(
            true
          ); else frameOptions.cUseMasterballOnLegendary.setSelected(false);
          if (info[0].equals("pokeballToUse")) {
            int index = 0;
            if (info[1].equals("smart")) {
              index = 0;
              frameOptions.bDefaultPokeball.setEnabled(false);
            } else if (info[1].equals("best")) {
              index = 1;
              frameOptions.bDefaultPokeball.setEnabled(false);
            } else if (info[1].equals("custom")) {
              index = 2;
              frameOptions.bDefaultPokeball.setEnabled(true);
            }
            frameOptions.bUsePokeball.setSelectedIndex(index);
          }
          if (info[0].equals("defaultPokeball")) {
            frameOptions.bDefaultPokeball.setSelectedItem(info[1]);
          }
          if (info[0].equals("limitBerryUsed")) if (info[1].equals("true")) {
            frameOptions.cLimitBerry.setSelected(true);
            frameOptions.fMaxBerry.setEnabled(true);
          } else {
            frameOptions.cLimitBerry.setSelected(false);
            frameOptions.fMaxBerry.setEnabled(false);
          }
          if (info[0].equals("maxBerryUsed")) frameOptions.fMaxBerry.setText(
            info[1]
          );
          if (info[0].equals("limitPokeballUsed")) if (info[1].equals("true")) {
            frameOptions.cLimitPokeball.setSelected(true);
            frameOptions.fMaxPokeball.setEnabled(true);
          } else {
            frameOptions.cLimitPokeball.setSelected(false);
            frameOptions.fMaxPokeball.setEnabled(false);
          }
          if (
            info[0].equals("maxPokeballUsed")
          ) frameOptions.fMaxPokeball.setText(info[1]);
        }
      }
    } catch (IOException e) {
      e.printStackTrace();
    }
  }

  public void loadDefaultSettingsPokemonRename() {
    BufferedReader br = new BufferedReader(
      new InputStreamReader(
        getClass().getResourceAsStream("/jPokéBotResources/settingsRename.txt")
      )
    );
    String line;
    try {
      while ((line = br.readLine()) != null) {
        String[] info = line.split("=");
        if (info.length == 2 && !info[1].equals("")) {
          if (info[0].equals("active")) if (
            info[1].equals("true")
          ) frameOptions.cActiveRename.setSelected(
            true
          ); else frameOptions.cActiveRename.setSelected(false); else if (
            info[0].equals("renameIV")
          ) if (info[1].equals("true")) frameOptions.cRenameIV.setSelected(
            true
          ); else frameOptions.cRenameIV.setSelected(false); else if (
            info[0].equals("renamePerfectMoves")
          ) if (
            info[1].equals("true")
          ) frameOptions.cRenamePerfectMoves.setSelected(
            true
          ); else frameOptions.cRenamePerfectMoves.setSelected(false);
        }
      }
    } catch (IOException e) {
      e.printStackTrace();
    }
  }

  public void updateSettings() {
    frameOptions.setDefaultRecycle(go);
    frameOptions.saveSettings();
  }
}

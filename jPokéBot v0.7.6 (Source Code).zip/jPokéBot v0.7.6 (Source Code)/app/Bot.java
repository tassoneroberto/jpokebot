package app;

import POGOProtos.Inventory.Item.ItemAwardOuterClass.ItemAward;
import POGOProtos.Inventory.Item.ItemIdOuterClass.ItemId;
import com.pokegoapi.api.PokemonGo;
import com.pokegoapi.api.inventory.Item;
import com.pokegoapi.api.inventory.Pokeball;
import com.pokegoapi.api.map.fort.Pokestop;
import com.pokegoapi.api.map.fort.PokestopLootResult;
import com.pokegoapi.api.map.pokemon.CatchResult;
import com.pokegoapi.api.map.pokemon.CatchablePokemon;
import com.pokegoapi.api.map.pokemon.encounter.EncounterResult;
import com.pokegoapi.api.pokemon.Pokemon;
import com.pokegoapi.api.settings.CatchOptions;
import com.pokegoapi.auth.GoogleAutoCredentialProvider;
import com.pokegoapi.exceptions.AsyncPokemonGoException;
import com.pokegoapi.exceptions.LoginFailedException;
import com.pokegoapi.exceptions.NoSuchItemException;
import com.pokegoapi.exceptions.RemoteServerException;
import com.pokegoapi.util.PokeDictionary;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Locale;
import java.util.MissingResourceException;
import java.util.Set;
import javax.swing.JTextArea;
import okhttp3.OkHttpClient;

public class Bot {

  public static final String VERSION = "0.7.6";
  public static final int NUMBER_RELEASE = 76;
  private PokemonGo go;
  private Thread farmer;
  private JTextArea display;
  // Item recycle options
  private boolean isActiveRecycle, isRecycleWhenFull, isKeepIncense, isKeepMasterball, isKeepTroyDisk, isKeepLuckyEgg, isAutoUpdate;
  private int kPokeball, kMegaball, kUltraball, kMasterball, kLuckyEgg, kIncense, kTroyDisk, kRazzBerry, kPotion, kSuperPotion, kHyperPotion, kMaxPotion, kRevive, kMaxRevive;
  // General options
  private boolean isGetLevelReward = true;
  private int scanWidth, timeToCollect, rescanTimeOut, speed;
  private HashSet<Integer> levelChangeCollect;
  // Pokémon catch options
  private boolean isActiveCatch, isUseMasterballOnLegendary, isLimitPokeball, isUseBerry, isLimitBerry;
  private String pokeballSelection;
  private Pokeball defaultPokeball;
  private int maxPokeball, maxBerry;
  private int timeOutCatch;
  private HashSet<Integer> legendary;
  // Pokémon transfer
  private boolean isActiveTransfer, isMinCP, isMinIV, isActiveSmartTransfer, isNeverTransferLegendary, isNeverTransferFavorite, isNeverTransferPerfectMoves;
  private int minCP, minIV, minAverage, maxDuplicate, priority;
  private HashMap<Integer, List<Pokemon>> idPokemonLists;
  private Collection<Pokemon> pokebank;
  // Pokémon rename
  private boolean isActiveRename, isRenameIV, isRenamePerfectMoves;

  private int level;
  private HashMap<ItemId, Integer> items;
  private FrameBot frameBot;
  private CatchOptions catchOptions;
  private Locale locale = new Locale("en");
  private String separator =
    "-------------------------------------------------------\n";
  private HashSet<Integer> fullyEvolved;

  public Bot(PokemonGo go, JTextArea display, FrameBot frameBot) {
    this.frameBot = frameBot;
    this.display = display;
    this.go = go;
  }

  public Bot(PokemonGo go, JTextArea display) {
    this.display = display;
    this.go = go;
  }

  public Bot(PokemonGo go) {
    this.go = go;
  }

  public static void main(String[] args)
    throws LoginFailedException, RemoteServerException, InterruptedException {
    FrameLogin fl = new FrameLogin();
    fl.setVisible(true);
  }

  public void startBot() {
    farmer = new PokeBot();
    farmer.start();
  }

  public void runBot() throws InterruptedException {
    display.append("Starting jPokéBot...\n");
    loadSettingsGeneral();
    display.append("General settings loaded!\n");
    level = go.getPlayerProfile().getStats().getLevel();
    loadSettingsRecycle();
    levelChangeCollect = new HashSet<Integer>();
    levelChangeCollect.add(5);
    levelChangeCollect.add(8);
    levelChangeCollect.add(10);
    levelChangeCollect.add(12);
    levelChangeCollect.add(15);
    levelChangeCollect.add(20);
    levelChangeCollect.add(25);
    levelChangeCollect.add(30);
    display.append("Item recycling settings loaded!\n");
    loadLegendaries();
    loadFullyEvolved();
    loadSettingsPokemonCatch();
    display.append("Pokémon catching settings loaded!\n");
    loadSettingsTransfer();
    display.append("Pokémon transfer settings loaded!\n");
    if (isActiveTransfer) {
      display.append("Checking Pokémon to tranfer...\n");
      loadPokebank();
      transferPokemon();
      try {
        go.getInventories().updateInventories(true);
      } catch (LoginFailedException e) {
        // TODO Auto-generated catch block
        e.printStackTrace();
      } catch (RemoteServerException e) {
        // TODO Auto-generated catch block
        e.printStackTrace();
      }
      display.append("Pokébank loaded!\n");
    }
    loadSettingsPokemonRename();
    display.append("Pokémon rename settings loaded!\n");
    if (isActiveRename) renameAllPokemon();

    /*
     * // TODO egg hatching boolean isActiveEggHatching = true; int
     * numberIncubators=go.getInventories().getIncubators().size(); if
     * (isActiveEggHatching) { if (numberIncubators != 0) {
     * Collection<EggPokemon> eggs =
     * go.getInventories().getHatchery().getEggs(); for (EggPokemon egg :
     * eggs) { EggIncubator
     * incubator=go.getInventories().getIncubators().get(0);
     * egg.incubate(incubator);
     * System.out.println("incubated egg "+egg.getEggKmWalkedTarget()+" in "
     * +incubator.getId()); break; } } }
     */

    display.append(
      "Location set to " + go.getLatitude() + " | " + go.getLongitude() + "\n"
    );
    items = new HashMap<ItemId, Integer>();

    updateInventory();
    display.append("Getting all near Pokéstop...\n");

    Collection<Pokestop> defaultPokestop = null;
    try {
      defaultPokestop = go.getMap().getMapObjects().getPokestops();
    } catch (LoginFailedException e1) {
      // TODO Auto-generated catch block
      e1.printStackTrace();
    } catch (RemoteServerException e1) {
      // TODO Auto-generated catch block
      e1.printStackTrace();
    }
    display.append("Total Pokéstop found: " + defaultPokestop.size() + "\n");

    List<CatchablePokemon> catchablePokemon = null;
    if (isActiveCatch) {
      try {
        catchablePokemon = go.getMap().getCatchablePokemon();
      } catch (LoginFailedException e) {
        // TODO Auto-generated catch block
        e.printStackTrace();
      } catch (RemoteServerException e) {
        // TODO Auto-generated catch block
        e.printStackTrace();
      }
      if (catchablePokemon.size() > 0) catchPokemons(catchablePokemon);
    }

    Collection<Pokestop> lootablePokestop = getLootablePokestop(
      go,
      defaultPokestop
    );
    if (lootablePokestop.size() > 0) {
      for (Pokestop ps : lootablePokestop) {
        if (ps.canLoot()) {
          lootPokestop(go, ps);
        }
      }
    }
    while (true) {
      lootablePokestop = getLootablePokestop(go, defaultPokestop);
      HashMap<Pokestop, Double> distancePokestop = new HashMap<Pokestop, Double>();
      for (Pokestop p : defaultPokestop) {
        distancePokestop.put(p, p.getDistance());
      }
      while (lootablePokestop.size() != 0) {
        try {
          go.getInventories().updateInventories(true);
        } catch (LoginFailedException e1) {
          // TODO Auto-generated catch block
          e1.printStackTrace();
        } catch (RemoteServerException e1) {
          // TODO Auto-generated catch block
          e1.printStackTrace();
        }
        frameBot.updateUserInfo();
        Pokestop nearestPokestop = null;
        double minDistance = Double.MAX_VALUE;
        for (Pokestop p : lootablePokestop) {
          if (defaultPokestop.contains(p)) {
            if (distancePokestop.get(p) < minDistance) {
              nearestPokestop = p;
              minDistance = distancePokestop.get(p);
            }
          }
        }
        if (nearestPokestop == null) {
          display.append(
            "No more lootable Pokéstop available. Rescanning in " +
            rescanTimeOut +
            " seconds...\n"
          );
          Thread.sleep(rescanTimeOut * 1000);
        } else {
          display.append(separator);
          try {
            display.append(
              "Pokéstop: " + nearestPokestop.getDetails().getName() + "\n"
            );
          } catch (LoginFailedException e1) {
            // TODO Auto-generated catch block
            e1.printStackTrace();
          } catch (RemoteServerException e1) {
            // TODO Auto-generated catch block
            e1.printStackTrace();
          }
          double toLat = nearestPokestop.getLatitude();
          double toLon = nearestPokestop.getLongitude();
          double distance = nearestPokestop.getDistance() / 1000;
          double timeToArrive = (distance / speed) * 3600;
          int approxTimeToArrive = (int) timeToArrive;
          int approxDistance = (int) (distance * 1000);
          display.append(
            "Moving... " +
            approxTimeToArrive +
            " seconds to arrive. [" +
            approxDistance +
            "m]\n"
          );
          Thread.sleep((long) (timeToArrive * 1000));
          go.setLatitude(toLat);
          go.setLongitude(toLon);

          if (isActiveCatch) {
            try {
              try {
                catchablePokemon = go.getMap().getCatchablePokemon();
              } catch (LoginFailedException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
              } catch (RemoteServerException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
              }
            } catch (AsyncPokemonGoException e) {
              e.printStackTrace();
            }
            catchPokemons(catchablePokemon);
          }

          display.append("Looting... ");
          lootPokestop(go, nearestPokestop);
          lootablePokestop = getLootablePokestop(go, defaultPokestop);
          for (Pokestop p : defaultPokestop) {
            distancePokestop.put(p, p.getDistance());
          }
        }
      }
      display.append(
        "No more lootable Pokéstop available. Rescanning in " +
        rescanTimeOut +
        " seconds...\n"
      );
      Thread.sleep(rescanTimeOut * 1000);
    }
  }

  private void loadLegendaries() {
    legendary = new HashSet<Integer>();
    legendary.add(132); // Ditto
    legendary.add(144); // Articuno
    legendary.add(145); // Zapdos
    legendary.add(146); // Moltres
    legendary.add(150); // Mewtwo
    legendary.add(151); // Mew
  }

  private void loadFullyEvolved() {
    fullyEvolved = new HashSet<Integer>();
    fullyEvolved.add(3);
    fullyEvolved.add(6);
    fullyEvolved.add(9);
    fullyEvolved.add(12);
    fullyEvolved.add(15);
    fullyEvolved.add(18);
    fullyEvolved.add(20);
    fullyEvolved.add(22);
    fullyEvolved.add(24);
    fullyEvolved.add(26);
    fullyEvolved.add(28);
    fullyEvolved.add(31);
    fullyEvolved.add(34);
    fullyEvolved.add(36);
    fullyEvolved.add(38);
    fullyEvolved.add(40);
    fullyEvolved.add(45);
    fullyEvolved.add(47);
    fullyEvolved.add(49);
    fullyEvolved.add(51);
    fullyEvolved.add(53);
    fullyEvolved.add(55);
    fullyEvolved.add(57);
    fullyEvolved.add(59);
    fullyEvolved.add(62);
    fullyEvolved.add(65);
    fullyEvolved.add(68);
    fullyEvolved.add(71);
    fullyEvolved.add(73);
    fullyEvolved.add(76);
    fullyEvolved.add(78);
    fullyEvolved.add(80);
    fullyEvolved.add(83);
    fullyEvolved.add(85);
    fullyEvolved.add(87);
    fullyEvolved.add(89);
    fullyEvolved.add(91);
    fullyEvolved.add(94);
    fullyEvolved.add(97);
    fullyEvolved.add(99);
    fullyEvolved.add(101);
    fullyEvolved.add(103);
    fullyEvolved.add(105);
    fullyEvolved.add(106);
    fullyEvolved.add(107);
    fullyEvolved.add(110);
    fullyEvolved.add(115);
    fullyEvolved.add(119);
    fullyEvolved.add(121);
    fullyEvolved.add(122);
    fullyEvolved.add(124);
    fullyEvolved.add(127);
    fullyEvolved.add(128);
    fullyEvolved.add(130);
    fullyEvolved.add(131);
    fullyEvolved.add(132);
    fullyEvolved.add(134);
    fullyEvolved.add(135);
    fullyEvolved.add(136);
    fullyEvolved.add(139);
    fullyEvolved.add(141);
    fullyEvolved.add(142);
    fullyEvolved.add(143);
    fullyEvolved.add(144);
    fullyEvolved.add(145);
    fullyEvolved.add(146);
    fullyEvolved.add(149);
    fullyEvolved.add(150);
    fullyEvolved.add(151);
  }

  public void stopBot() {
    farmer.interrupt();
    // TODO add restart
  }

  public class PokeBot extends Thread {

    public void run() {
      try {
        runBot();
      } catch (InterruptedException e) {
        display.append("\n\n*** Bot stopped ***\n");
        frameBot.buttonStop.setEnabled(false);
        frameBot.buttonOptions.setEnabled(true);
        frameBot.buttonStart.setEnabled(true);
      }
    }
  }

  public static PokemonGo connect(String email, String password)
    throws LoginFailedException, RemoteServerException {
    OkHttpClient httpClient = new OkHttpClient();
    GoogleAutoCredentialProvider provider = new GoogleAutoCredentialProvider(
      httpClient,
      email,
      password
    );
    PokemonGo go = new PokemonGo(httpClient);
    go.login(provider);
    return go;
  }

  private void loadSettingsRecycle() {
    BufferedReader br = new BufferedReader(
      new InputStreamReader(
        getClass()
          .getResourceAsStream("/jPokéBotResources/settingsItemRecycle.txt")
      )
    );
    String line;
    try {
      while ((line = br.readLine()) != null) {
        String[] info = line.split("=");
        if (info.length == 2 && !info[1].equals("")) {
          if (info[0].equals("active")) if (
            info[1].equals("true")
          ) isActiveRecycle = true; else isActiveRecycle = false; else if (
            info[0].equals("autoUpdate")
          ) if (info[1].equals("true")) isAutoUpdate = true; else isAutoUpdate =
            false; else if (info[0].equals("recycleWhenFull")) if (
            info[1].equals("true")
          ) isRecycleWhenFull = true; else isRecycleWhenFull = false; else if (
            info[0].equals("keepMasterball")
          ) if (info[1].equals("true")) isKeepMasterball =
            true; else isKeepMasterball = false; else if (
            info[0].equals("keepIncense")
          ) if (info[1].equals("true")) isKeepIncense =
            true; else isKeepIncense = false; else if (
            info[0].equals("keepTroyDisk")
          ) if (info[1].equals("true")) isKeepTroyDisk =
            true; else isKeepTroyDisk = false; else if (
            info[0].equals("keepLuckyEgg")
          ) if (info[1].equals("true")) isKeepLuckyEgg =
            true; else isKeepLuckyEgg = false; else if (
            info[0].equals("pokeball")
          ) kPokeball = Integer.parseInt(info[1]); else if (
            info[0].equals("megaball")
          ) kMegaball = Integer.parseInt(info[1]); else if (
            info[0].equals("ultraball")
          ) kUltraball = Integer.parseInt(info[1]); else if (
            info[0].equals("masterball")
          ) if (info[1].equals("infinity")) kMasterball =
            Integer.MAX_VALUE; else kMasterball =
            Integer.parseInt(info[1]); else if (
            info[0].equals("potion")
          ) kPotion = Integer.parseInt(info[1]); else if (
            info[0].equals("superpotion")
          ) kSuperPotion = Integer.parseInt(info[1]); else if (
            info[0].equals("hyperpotion")
          ) kHyperPotion = Integer.parseInt(info[1]); else if (
            info[0].equals("maxpotion")
          ) kMaxPotion = Integer.parseInt(info[1]); else if (
            info[0].equals("revive")
          ) kRevive = Integer.parseInt(info[1]); else if (
            info[0].equals("maxrevive")
          ) kMaxRevive = Integer.parseInt(info[1]); else if (
            info[0].equals("razzberry")
          ) kRazzBerry = Integer.parseInt(info[1]); else if (
            info[0].equals("incense")
          ) if (info[1].equals("infinity")) kIncense =
            Integer.MAX_VALUE; else kIncense =
            Integer.parseInt(info[1]); else if (info[0].equals("troydisk")) if (
            info[1].equals("infinity")
          ) kTroyDisk = Integer.MAX_VALUE; else kTroyDisk =
            Integer.parseInt(info[1]); else if (info[0].equals("luckyegg")) if (
            info[1].equals("infinity")
          ) kLuckyEgg = Integer.MAX_VALUE; else kLuckyEgg =
            Integer.parseInt(info[1]);
        }
      }
    } catch (IOException e) {
      e.printStackTrace();
    }
  }

  private void loadSettingsGeneral() {
    BufferedReader br = new BufferedReader(
      new InputStreamReader(
        getClass().getResourceAsStream("/jPokéBotResources/settingsGeneral.txt")
      )
    );
    String line;
    try {
      while ((line = br.readLine()) != null) {
        String[] info = line.split("=");
        if (info.length == 2 && !info[1].equals("")) {
          if (info[0].equals("width")) scanWidth =
            Integer.parseInt(info[1]); else if (
            info[0].equals("timeToCollect")
          ) timeToCollect = Integer.parseInt(info[1]); else if (
            info[0].equals("rescanTimeOut")
          ) rescanTimeOut = Integer.parseInt(info[1]); else if (
            info[0].equals("speed")
          ) speed = Integer.parseInt(info[1]); else if (
            info[0].equals("getLevelReward")
          ) {
            if (info[1].equals("true")) isGetLevelReward = true; else if (
              info[1].equals("false")
            ) isGetLevelReward = false;
          }
        }
      }
    } catch (IOException e) {
      e.printStackTrace();
    }

    go.getMap().setDefaultWidth(scanWidth);
  }

  private void loadSettingsTransfer() {
    BufferedReader br = new BufferedReader(
      new InputStreamReader(
        getClass()
          .getResourceAsStream("/jPokéBotResources/settingsTransfer.txt")
      )
    );
    String line;
    try {
      while ((line = br.readLine()) != null) {
        String[] info = line.split("=");
        if (info.length == 2 && !info[1].equals("")) {
          if (info[0].equals("active")) if (info[1].equals("true")) {
            isActiveTransfer = true;
          } else {
            isActiveTransfer = false;
          } else if (info[0].equals("minCP")) minCP =
            Integer.parseInt(info[1]); else if (info[0].equals("minIV")) minIV =
            Integer.parseInt(info[1]); else if (
            info[0].equals("keepMinCP")
          ) if (info[1].equals("true")) {
            isMinCP = true;
          } else {
            isMinCP = false;
          } else if (info[0].equals("keepMinIV")) if (info[1].equals("true")) {
            isMinIV = true;
          } else {
            isMinIV = false;
          } else if (info[0].equals("keepLegendaries")) if (
            info[1].equals("true")
          ) isNeverTransferLegendary = true; else {
            isNeverTransferLegendary = false;
          } else if (info[0].equals("keepFavorites")) if (
            info[1].equals("true")
          ) isNeverTransferFavorite = true; else {
            isNeverTransferFavorite = false;
          } else if (info[0].equals("keepPerfectMoves")) if (
            info[1].equals("true")
          ) isNeverTransferPerfectMoves = true; else {
            isNeverTransferPerfectMoves = false;
          } else if (info[0].equals("activeSmartTransfer")) if (
            info[1].equals("true")
          ) {
            isActiveSmartTransfer = true;
          } else {
            isActiveSmartTransfer = false;
          } else if (info[0].equals("priority")) {
            priority = Integer.parseInt(info[1]);
          } else if (info[0].equals("maxDuplicate")) maxDuplicate =
            Integer.parseInt(info[1]); else if (
            info[0].equals("minAverage")
          ) minAverage = Integer.parseInt(info[1]);
        }
      }
    } catch (IOException e) {
      e.printStackTrace();
    }
  }

  private void loadSettingsPokemonCatch() {
    catchOptions = new CatchOptions(go);
    BufferedReader br = new BufferedReader(
      new InputStreamReader(
        getClass()
          .getResourceAsStream("/jPokéBotResources/settingsPokemonCatch.txt")
      )
    );
    String line;
    try {
      while ((line = br.readLine()) != null) {
        String[] info = line.split("=");
        if (info.length == 2 && !info[1].equals("")) {
          if (info[0].equals("active")) if (
            info[1].equals("true")
          ) isActiveCatch = true; else isActiveCatch = false; else if (
            info[0].equals("timeOutCatch")
          ) timeOutCatch = Integer.parseInt(info[1]); else if (
            info[0].equals("useBerry")
          ) if (info[1].equals("true")) isUseBerry = true; else isUseBerry =
            false; else if (info[0].equals("useMasterballOnLegendary")) if (
            info[1].equals("true")
          ) isUseMasterballOnLegendary = true; else isUseMasterballOnLegendary =
            false; else if (info[0].equals("pokeballToUse")) {
            pokeballSelection = info[1];
          } else if (info[0].equals("defaultPokeball")) {
            if (info[1].equals("Pokéball")) defaultPokeball =
              Pokeball.POKEBALL; else if (
              info[1].equals("Megaball")
            ) defaultPokeball = Pokeball.GREATBALL; else if (
              info[1].equals("Ultraball")
            ) defaultPokeball = Pokeball.ULTRABALL; else if (
              info[1].equals("Masterball")
            ) defaultPokeball = Pokeball.MASTERBALL;
          } else if (info[0].equals("limitBerryUsed")) if (
            info[1].equals("true")
          ) isLimitBerry = true; else isLimitBerry = false; else if (
            info[0].equals("limitPokeballUsed")
          ) if (info[1].equals("true")) isLimitPokeball =
            true; else isLimitPokeball = false; else if (
            info[0].equals("maxBerryUsed")
          ) maxBerry = Integer.parseInt(info[1]); else if (
            info[0].equals("maxPokeballUsed")
          ) maxPokeball = Integer.parseInt(info[1]);
        }
      }
    } catch (IOException e) {
      e.printStackTrace();
    }

    catchOptions.useRazzberries(isUseBerry);
    if (isLimitBerry) catchOptions.maxRazzberries(maxBerry);
    if (isLimitPokeball) catchOptions.maxPokeballs(maxPokeball);
    if (pokeballSelection.equals("smart")) catchOptions.useSmartSelect(
      true
    ); else if (pokeballSelection.equals("best")) catchOptions.useBestBall(
      true
    ); else if (pokeballSelection.equals("custom")) catchOptions.usePokeball(
      defaultPokeball
    );
  }

  private void loadSettingsPokemonRename() {
    BufferedReader br = new BufferedReader(
      new InputStreamReader(
        getClass().getResourceAsStream("/jPokéBotResources/settingsRename.txt")
      )
    );
    String line;
    try {
      while ((line = br.readLine()) != null) {
        String[] info = line.split("=");
        if (info.length == 2 && !info[1].equals("")) {
          if (info[0].equals("active")) if (
            info[1].equals("true")
          ) isActiveRename = true; else isActiveRename = false;
          if (info[0].equals("renameIV")) if (
            info[1].equals("true")
          ) isRenameIV = true; else isRenameIV = false;
          if (info[0].equals("renamePerfectMoves")) if (
            info[1].equals("true")
          ) isRenamePerfectMoves = true; else isRenamePerfectMoves = false;
        }
      }
    } catch (IOException e) {
      e.printStackTrace();
    }
  }

  public static double distFromTo(
    double lat1,
    double lng1,
    double lat2,
    double lng2
  ) {
    double earthRadius = 6371;
    double dLat = Math.toRadians(lat2 - lat1);
    double dLng = Math.toRadians(lng2 - lng1);
    double a =
      Math.sin(dLat / 2) *
      Math.sin(dLat / 2) +
      Math.cos(Math.toRadians(lat1)) *
      Math.cos(Math.toRadians(lat2)) *
      Math.sin(dLng / 2) *
      Math.sin(dLng / 2);
    double c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
    float dist = (float) (earthRadius * c);

    return dist;
  }

  private void loadPokebank() {
    idPokemonLists = new HashMap<Integer, List<Pokemon>>();
    try {
      go.getInventories().updateInventories(true);
    } catch (LoginFailedException e) {
      e.printStackTrace();
    } catch (RemoteServerException e) {
      e.printStackTrace();
    }
    pokebank = go.getInventories().getPokebank().getPokemons();
    for (Pokemon p : pokebank) {
      int id = p.getPokemonId().getNumber();
      List<Pokemon> newList;
      if (!idPokemonLists.containsKey(id)) {
        newList = new LinkedList<Pokemon>();
      } else {
        newList = idPokemonLists.get(id);
      }
      newList.add(p);
      idPokemonLists.put(id, newList);
    }
  }

  private static Collection<Pokestop> getLootablePokestop(
    PokemonGo go,
    Collection<Pokestop> defaultPokestop
  ) {
    Collection<Pokestop> lootablePokestop = new LinkedList<Pokestop>();
    for (Pokestop pokestop : defaultPokestop) {
      if (pokestop.canLoot(true)) {
        lootablePokestop.add(pokestop);
      }
    }
    return lootablePokestop;
  }

  private void lootPokestop(PokemonGo go, Pokestop ps)
    throws InterruptedException {
    PokestopLootResult loot = null;
    try {
      loot = ps.loot();
    } catch (LoginFailedException e) {
      // TODO Auto-generated catch block
      e.printStackTrace();
      return;
    } catch (RemoteServerException e) {
      // TODO Auto-generated catch block
      e.printStackTrace();
      return;
    }
    int xp = loot.getExperience();
    List<ItemAward> lootedItems = loot.getItemsAwarded();
    if (xp == 0) {
      display.append("Softbanned!\n");
      stopBot();
    } else {
      display.append("[XP: " + xp + "][ITEMS: ");
      if (lootedItems.size() > 1) {
        HashMap<String, Integer> itemCount = new HashMap<String, Integer>();
        for (ItemAward item : lootedItems) {
          String name = fixItemName(item.getItemId().name());
          if (!itemCount.containsKey(name)) {
            itemCount.put(name, 1);
          } else {
            int old = itemCount.get(name);
            old++;
            itemCount.put(name, old);
          }
        }
        display.append(itemCount + "]\n");
        if (isActiveRecycle) if (!isRecycleWhenFull) recycleItems();
      } else {
        display.append(" Bag full]\n");
        if (isActiveRecycle) recycleItems();
      }
      try {
        go.getInventories().updateInventories(true);
      } catch (LoginFailedException e1) {
        // TODO Auto-generated catch block
        e1.printStackTrace();
      } catch (RemoteServerException e1) {
        // TODO Auto-generated catch block
        e1.printStackTrace();
      }
      if (level != go.getPlayerProfile().getStats().getLevel()) {
        display.append(
          "LEVEL UP! " +
          level +
          "→" +
          go.getPlayerProfile().getStats().getLevel() +
          "\n"
        );
        level = go.getPlayerProfile().getStats().getLevel();
        if (isGetLevelReward) {
          List<ItemAward> reward = null;
          try {
            reward =
              go.getPlayerProfile().acceptLevelUpRewards(level).getRewards();
          } catch (RemoteServerException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
          } catch (LoginFailedException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
          }
          display.append("Reward: ");
          for (ItemAward item : reward) {
            display.append(
              item.getItemCount() +
              "x" +
              fixItemName(item.getItemId().toString()) +
              " "
            );
          }
          display.append("\n");
        }
        if (isAutoUpdate && levelChangeCollect.contains(level)) {
          frameBot.updateSettings();
          display.append("Updated item recycle settings!\n");
        }
      }
    }
    Thread.sleep(timeToCollect * 1000);
  }

  private void updateInventory() {
    try {
      go.getInventories().updateInventories(true);
    } catch (LoginFailedException e) {
      e.printStackTrace();
    } catch (RemoteServerException e) {
      e.printStackTrace();
    }
    Collection<Item> current = go.getInventories().getItemBag().getItems();
    for (Item item : current) {
      items.put(item.getItemId(), item.getCount());
    }
  }

  private void recycleItems() {
    try {
      updateInventory();
      if (items.containsKey(ItemId.ITEM_POKE_BALL)) if (
        items.get(ItemId.ITEM_POKE_BALL) > kPokeball
      ) {
        int drop = items.get(ItemId.ITEM_POKE_BALL) - kPokeball;
        go
          .getInventories()
          .getItemBag()
          .removeItem(ItemId.ITEM_POKE_BALL, drop);
        display.append("Dropped " + drop + "x Pokéball\n");
      }
      if (items.containsKey(ItemId.ITEM_GREAT_BALL)) if (
        items.get(ItemId.ITEM_GREAT_BALL) > kMegaball
      ) {
        int drop = items.get(ItemId.ITEM_GREAT_BALL) - kMegaball;
        go
          .getInventories()
          .getItemBag()
          .removeItem(ItemId.ITEM_GREAT_BALL, drop);
        display.append("Dropped " + drop + "x Megaball\n");
      }
      if (items.containsKey(ItemId.ITEM_ULTRA_BALL)) if (
        items.get(ItemId.ITEM_ULTRA_BALL) > kUltraball
      ) {
        int drop = items.get(ItemId.ITEM_ULTRA_BALL) - kUltraball;
        go
          .getInventories()
          .getItemBag()
          .removeItem(ItemId.ITEM_ULTRA_BALL, drop);
        display.append("Dropped " + drop + "x Ultraball\n");
      }
      if (items.containsKey(ItemId.ITEM_POTION)) if (
        items.get(ItemId.ITEM_POTION) > kPotion
      ) {
        int drop = items.get(ItemId.ITEM_POTION) - kPotion;
        go.getInventories().getItemBag().removeItem(ItemId.ITEM_POTION, drop);
        display.append("Dropped " + drop + "x Potion\n");
      }
      if (items.containsKey(ItemId.ITEM_SUPER_POTION)) if (
        items.get(ItemId.ITEM_SUPER_POTION) > kSuperPotion
      ) {
        int drop = items.get(ItemId.ITEM_SUPER_POTION) - kSuperPotion;
        go
          .getInventories()
          .getItemBag()
          .removeItem(ItemId.ITEM_SUPER_POTION, drop);
        display.append("Dropped " + drop + "x Super Potion\n");
      }
      if (items.containsKey(ItemId.ITEM_HYPER_POTION)) if (
        items.get(ItemId.ITEM_HYPER_POTION) > kHyperPotion
      ) {
        int drop = items.get(ItemId.ITEM_HYPER_POTION) - kHyperPotion;
        go
          .getInventories()
          .getItemBag()
          .removeItem(ItemId.ITEM_HYPER_POTION, drop);
        display.append("Dropped " + drop + "x Hyper Potion\n");
      }
      if (items.containsKey(ItemId.ITEM_MAX_POTION)) if (
        items.get(ItemId.ITEM_MAX_POTION) > kMaxPotion
      ) {
        int drop = items.get(ItemId.ITEM_MAX_POTION) - kMaxPotion;
        go
          .getInventories()
          .getItemBag()
          .removeItem(ItemId.ITEM_MAX_POTION, drop);
        display.append("Dropped " + drop + "x Max Potion\n");
      }
      if (items.containsKey(ItemId.ITEM_REVIVE)) if (
        items.get(ItemId.ITEM_REVIVE) > kRevive
      ) {
        int drop = items.get(ItemId.ITEM_REVIVE) - kRevive;
        go.getInventories().getItemBag().removeItem(ItemId.ITEM_REVIVE, drop);
        display.append("Dropped " + drop + "x Revive\n");
      }
      if (items.containsKey(ItemId.ITEM_MAX_REVIVE)) if (
        items.get(ItemId.ITEM_MAX_REVIVE) > kMaxRevive
      ) {
        int drop = items.get(ItemId.ITEM_MAX_REVIVE) - kMaxRevive;
        go
          .getInventories()
          .getItemBag()
          .removeItem(ItemId.ITEM_MAX_REVIVE, drop);
        display.append("Dropped " + drop + "x Max Revive\n");
      }
      if (items.containsKey(ItemId.ITEM_RAZZ_BERRY)) if (
        items.get(ItemId.ITEM_RAZZ_BERRY) > kRazzBerry
      ) {
        int drop = items.get(ItemId.ITEM_RAZZ_BERRY) - kRazzBerry;
        go
          .getInventories()
          .getItemBag()
          .removeItem(ItemId.ITEM_RAZZ_BERRY, drop);
        display.append("Dropped " + drop + "x RazzBerry\n");
      }
      if (!isKeepMasterball) {
        if (items.containsKey(ItemId.ITEM_MASTER_BALL)) if (
          items.get(ItemId.ITEM_MASTER_BALL) > kMasterball
        ) {
          int drop = items.get(ItemId.ITEM_MASTER_BALL) - kMasterball;
          go
            .getInventories()
            .getItemBag()
            .removeItem(ItemId.ITEM_MASTER_BALL, drop);
          display.append("Dropped " + drop + "x Masterball\n");
        }
      }
      if (!isKeepLuckyEgg) {
        if (items.containsKey(ItemId.ITEM_LUCKY_EGG)) if (
          items.get(ItemId.ITEM_LUCKY_EGG) > kLuckyEgg
        ) {
          int drop = items.get(ItemId.ITEM_LUCKY_EGG) - kLuckyEgg;
          go
            .getInventories()
            .getItemBag()
            .removeItem(ItemId.ITEM_LUCKY_EGG, drop);
          display.append("Dropped " + drop + "x Lucky Egg\n");
        }
      }
      if (!isKeepTroyDisk) {
        if (items.containsKey(ItemId.ITEM_TROY_DISK)) if (
          items.get(ItemId.ITEM_TROY_DISK) > kTroyDisk
        ) {
          int drop = items.get(ItemId.ITEM_TROY_DISK) - kTroyDisk;
          go
            .getInventories()
            .getItemBag()
            .removeItem(ItemId.ITEM_TROY_DISK, drop);
          display.append("Dropped " + drop + "x Lure Module\n");
        }
      }
      if (!isKeepIncense) {
        if (items.containsKey(ItemId.ITEM_INCENSE_ORDINARY)) if (
          items.get(ItemId.ITEM_INCENSE_ORDINARY) > kIncense
        ) {
          int drop = items.get(ItemId.ITEM_INCENSE_ORDINARY) - kIncense;
          go
            .getInventories()
            .getItemBag()
            .removeItem(ItemId.ITEM_INCENSE_ORDINARY, drop);
          display.append("Dropped " + drop + "x Incense\n");
        }
      }
    } catch (LoginFailedException e) {} catch (RemoteServerException e) {}
  }

  private void catchPokemons(List<CatchablePokemon> list)
    throws InterruptedException {
    for (CatchablePokemon pokemon : list) {
      display.append(
        "Trying to catch a " +
        PokeDictionary.getDisplayName(
          pokemon.getPokemonId().getNumber(),
          new Locale("en")
        ) +
        "... "
      );
      try {
        go.getInventories().updateInventories(true);
      } catch (LoginFailedException e1) {
        e1.printStackTrace();
      } catch (RemoteServerException e1) {
        e1.printStackTrace();
      }
      boolean havePokeball = false;
      for (Item item : go.getInventories().getItemBag().getItems()) {
        item.getItemId();
        item.getItemId();
        item.getItemId();
        item.getItemId();
        if (
          item.getItemId().equals(ItemId.ITEM_POKE_BALL) ||
          item.getItemId().equals(ItemId.ITEM_GREAT_BALL) ||
          item.getItemId().equals(ItemId.ITEM_ULTRA_BALL) ||
          item.getItemId().equals(ItemId.ITEM_MASTER_BALL)
        ) if (item.getCount() > 0) havePokeball = true;
      }
      if (havePokeball) {
        if (isUseBerry) if (
          go
            .getInventories()
            .getItemBag()
            .getItem(ItemId.ITEM_RAZZ_BERRY)
            .getCount() <=
          0
        ) catchOptions.useRazzberries(false); else catchOptions.useRazzberries(
          true
        );
        if (isUseMasterballOnLegendary) if (
          legendary.contains(pokemon.getPokemonId().getNumber())
        ) {
          catchOptions.noMasterBall(false);
          catchOptions.usePokeball(Pokeball.MASTERBALL);
          catchOptions.useBestBall(true);
        }
        CatchResult catchResult = null;
        EncounterResult encounterResult = null;
        try {
          encounterResult = pokemon.encounterNormalPokemon();
          if (encounterResult.wasSuccessful() && encounterResult != null) {
            catchResult = pokemon.catchPokemon(catchOptions);
          } else display.append("encounter failed!\n");
        } catch (LoginFailedException e) {
          e.printStackTrace();
        } catch (RemoteServerException e) {
          e.printStackTrace();
        } catch (NoSuchItemException e) {
          e.printStackTrace();
        } catch (AsyncPokemonGoException e) {
          display.append("network error!\n"); // TODO fixme
          e.printStackTrace();
        }
        if (encounterResult.wasSuccessful()) if (
          catchResult != null && !catchResult.isFailed()
        ) {
          display.append(
            "caught! [CP " + encounterResult.getPokemonData().getCp() + "]\n"
          );
          if (isActiveTransfer) {
            loadPokebank();
            transferPokemon();
            try {
              go.getInventories().updateInventories(true);
            } catch (LoginFailedException e) {
              // TODO Auto-generated catch block
              e.printStackTrace();
            } catch (RemoteServerException e) {
              // TODO Auto-generated catch block
              e.printStackTrace();
            }
          }
          if (isActiveRename) renameAllPokemon();
        } else {
          display.append("escaped!\n");
        }
      } else {
        display.append("can't catch! No Pokéball!\n");
      }

      catchOptions.usePokeball(defaultPokeball);
      if (pokeballSelection.equals("smart")) catchOptions.useSmartSelect(
        true
      ); else if (pokeballSelection.equals("best")) catchOptions.useBestBall(
        true
      );
      catchOptions.noMasterBall(true);

      Thread.sleep(timeOutCatch * 1000);
    }
  }

  private boolean transferPokemon() {
    boolean transfered = false;
    Set<Integer> keys = idPokemonLists.keySet();
    for (Integer key : keys) {
      List<Pokemon> currentList = idPokemonLists.get(key);
      List<Pokemon> toTransfer = new LinkedList<Pokemon>();
      if (currentList.size() > maxDuplicate) {
        for (Pokemon p : currentList) {
          if (
            p.equals(go.getPlayerProfile().getPlayerData().getBuddyPokemon())
          ) {
            continue;
          }
          if (
            isNeverTransferLegendary &&
            legendary.contains(p.getPokemonId().getNumber())
          ) {
            continue;
          }
          if (isNeverTransferFavorite && p.isFavorite()) {
            continue;
          }
          if (isMinCP && p.getCp() > minCP) {
            continue;
          }
          if (isMinIV && p.getIvInPercentage() > minIV) {
            continue;
          }
          if (isActiveSmartTransfer) {
            int cpPercentageMaxPlayerLevel = 100;
            try {
              cpPercentageMaxPlayerLevel = p.getCPInPercentageMaxPlayerLevel();
            } catch (NoSuchItemException e) {
              // TODO Auto-generated catch block
              e.printStackTrace();
            }
            double average =
              (
                cpPercentageMaxPlayerLevel *
                priority +
                p.getIvInPercentage() *
                (100 - priority)
              ) /
              100;
            if (average > minAverage) continue;
          }
          if (isNeverTransferPerfectMoves) {
            if (fullyEvolved.contains(p.getPokemonId().getNumber())) {
              String[] perfectMoves = frameBot.moveset.get(
                p.getPokemonId().getNumber()
              );
              if (
                p.getMove1().equals(perfectMoves[0]) &&
                p.getMove2().equals(perfectMoves[1])
              ) continue;
            }
          }
          toTransfer.add(p);
        }
      }
      if (toTransfer.size() <= currentList.size() - maxDuplicate) {
        for (Pokemon p : toTransfer) {
          display.append(
            "Transfered " +
            PokeDictionary.getDisplayName(
              p.getPokemonId().getNumber(),
              locale
            ) +
            " [CP " +
            p.getCp() +
            "][IV " +
            p.getIvInPercentage() +
            "%]\n"
          );
          try {
            p.transferPokemon();
          } catch (LoginFailedException e) {
            e.printStackTrace();
          } catch (RemoteServerException e) {
            e.printStackTrace();
          }
          transfered = true;
        }
      } else {
        Collections.sort(
          toTransfer,
          (a, b) -> {
            try {
              return (
                  (
                    (
                      a.getCPInPercentageActualPlayerLevel() +
                      a.getIvInPercentage()
                    ) /
                    2
                  ) <
                  (
                    (
                      b.getCPInPercentageActualPlayerLevel() +
                      b.getIvInPercentage()
                    ) /
                    2
                  )
                )
                ? -1
                : 1;
            } catch (NoSuchItemException e) {
              e.printStackTrace();
            }
            return 0;
          }
        );
        for (int i = 0; i < currentList.size() - maxDuplicate; i++) {
          Pokemon p = toTransfer.get(i);
          display.append(
            "Transfered " +
            PokeDictionary.getDisplayName(
              p.getPokemonId().getNumber(),
              locale
            ) +
            " [CP " +
            p.getCp() +
            "][IV " +
            p.getIvInPercentage() +
            "%]\n"
          );
          try {
            p.transferPokemon();
          } catch (LoginFailedException e) {
            e.printStackTrace();
          } catch (RemoteServerException e) {
            e.printStackTrace();
          }
          transfered = true;
        }
      }
    }
    return transfered;
  }

  private void renameAllPokemon() {
    List<Pokemon> list = go.getInventories().getPokebank().getPokemons();
    for (int i = 0; i < list.size(); i++) {
      renamePokemon(list.get(i));
    }
  }

  private void renamePokemon(Pokemon pokemon) {
    String name = PokeDictionary.getDisplayName(
      pokemon.getPokemonId().getNumber(),
      locale
    );
    String oldNickname = pokemon.getNickname();
    if (oldNickname.equals("")) oldNickname = name;
    String newNickname = null;
    boolean pm1 = false;
    boolean pm2 = false;
    String moves = "";
    if (isRenamePerfectMoves) {
      String[] perfectMoves = frameBot.moveset.get(
        pokemon.getPokemonId().getNumber()
      );
      if (pokemon.getMove1().name().equals(perfectMoves[0])) pm1 = true;
      if (pokemon.getMove2().name().equals(perfectMoves[1])) pm2 = true;
      if (pm1 && pm2) moves = "¤"; else if (pm1) moves = "¹"; else if (
        pm2
      ) moves = "²";
    }
    if (isRenameIV && isRenamePerfectMoves) {
      if (name.length() > 9) name = name.substring(0, 9);
      newNickname =
        name + new Double(pokemon.getIvInPercentage()).intValue() + moves;
    } else if (isRenameIV) {
      if (name.length() > 10) name = name.substring(0, 10);
      newNickname = name + new Double(pokemon.getIvInPercentage()).intValue();
    } else if (isRenamePerfectMoves) {
      newNickname =
        PokeDictionary.getDisplayName(
          pokemon.getPokemonId().getNumber(),
          locale
        ) +
        moves;
    } else newNickname =
      PokeDictionary.getDisplayName(pokemon.getPokemonId().getNumber(), locale);
    if (!oldNickname.equals(newNickname)) {
      try {
        pokemon.renamePokemon(newNickname);
        go.getInventories().updateInventories(true);
      } catch (MissingResourceException e) {
        e.printStackTrace();
      } catch (LoginFailedException e) {
        e.printStackTrace();
      } catch (RemoteServerException e) {
        e.printStackTrace();
      }
      display.append(oldNickname + " renamed to " + newNickname + "\n");
    }
  }

  public String printBasicInfo() {
    StringBuilder sb = new StringBuilder();
    sb.append("BASIC INFO & STATS\n");
    sb.append(
      "Username: " + go.getPlayerProfile().getPlayerData().getUsername() + "\n"
    );
    String team = go.getPlayerProfile().getPlayerData().getTeam().name();
    sb.append("Team: " + team);
    sb.append("\n");
    sb.append("Level: " + go.getPlayerProfile().getStats().getLevel() + "\n");
    sb.append(
      "Total XP: " + go.getPlayerProfile().getStats().getExperience() + "\n"
    );
    sb.append(
      "XP next level: " +
      (
        go.getPlayerProfile().getStats().getNextLevelXp() -
        go.getPlayerProfile().getStats().getExperience()
      ) +
      "\n"
    );
    sb.append(
      "Km walked: " + go.getPlayerProfile().getStats().getKmWalked() + "\n"
    );
    sb.append(
      "Pokéballs thrown: " +
      go.getPlayerProfile().getStats().getPokeballsThrown() +
      "\n"
    );
    sb.append(
      "Eggs hatched: " +
      go.getPlayerProfile().getStats().getEggsHatched() +
      "\n"
    );
    sb.append(
      "Pokéstop visited: " +
      go.getPlayerProfile().getStats().getPokeStopVisits() +
      "\n"
    );
    sb.append(
      "Encountered:" +
      go.getPlayerProfile().getStats().getPokemonsEncountered() +
      "\n"
    );
    sb.append(
      "Caught:" + go.getPlayerProfile().getStats().getPokemonsCaptured() + "\n"
    );
    sb.append("\n");
    sb.append("LOCATION\n");
    sb.append("Latitude: " + go.getLatitude() + "\n");
    sb.append("Longitude: " + go.getLongitude() + "\n");
    sb.append("Altitude: " + go.getAltitude() + "\n");
    sb.append("\n");
    sb.append("POKEDEX\n");
    sb.append(
      "Unique caught:" +
      go.getPlayerProfile().getStats().getUniquePokedexEntries() +
      "/151\n"
    );

    return sb.toString();
  }

  public String printPokebank(String sortBy) {
    StringBuilder sb = new StringBuilder();
    sb.append("<html><body><table width=\"100%\" border=\"1\">");
    try {
      go.getInventories().updateInventories(true);
    } catch (LoginFailedException e) {
      e.printStackTrace();
    } catch (RemoteServerException e) {
      e.printStackTrace();
    } catch (AsyncPokemonGoException e) {
      e.printStackTrace();
    }
    List<Pokemon> pokebank = go.getInventories().getPokebank().getPokemons();
    if (sortBy.equals("cp") || sortBy.equals("default")) Collections.sort(
      pokebank,
      (a, b) -> a.getCp() > b.getCp() ? -1 : 1
    ); else if (sortBy.equals("iv")) Collections.sort(
      pokebank,
      (a, b) -> a.getIvInPercentage() > b.getIvInPercentage() ? -1 : 1
    ); else if (sortBy.equals("number")) Collections.sort(
      pokebank,
      (a, b) ->
        a.getPokemonId().getNumber() < b.getPokemonId().getNumber() ? -1 : 1
    ); else if (sortBy.equals("az")) Collections.sort(
      pokebank,
      (a, b) -> a.getPokemonId().name().compareTo(b.getPokemonId().name())
    );

    for (Pokemon pokemon : pokebank) {
      String fixedNumber = String.format(
        "%03d",
        pokemon.getPokemonId().getNumber()
      );
      Bot.class.getClassLoader();
      String imgsrc = ClassLoader
        .getSystemResource(
          "jPokéBotResources/images/pokemon/" + fixedNumber + ".png"
        )
        .toString();
      sb.append(
        "<tr><td>#" +
        pokemon.getPokemonId().getNumber() +
        "</td><td><img src=\"" +
        imgsrc +
        "\" width=\"10px\" height=\"10px\" /></td><td>" +
        PokeDictionary.getDisplayName(
          pokemon.getPokemonId().getNumber(),
          new Locale("en")
        ) +
        "</td><td>CP " +
        pokemon.getCp() +
        "</td><td>IV " +
        pokemon.getIvInPercentage() +
        "%</td><td>Candy " +
        pokemon.getCandy() +
        "</td><td>" +
        pokemon.getMove1().name().replaceAll("_FAST", "").replaceAll("_", " ") +
        "</td><td>" +
        pokemon.getMove2().name().replaceAll("_", " ") +
        "</td></tr>"
      );
    }
    return sb.toString();
  }

  public String printInventory() {
    StringBuilder sb = new StringBuilder();
    sb.append("<html><body><table>");
    List<Item> items = new LinkedList<Item>(
      go.getInventories().getItemBag().getItems()
    );
    Collections.sort(
      items,
      (a, b) -> a.getItemId().getNumber() < b.getItemId().getNumber() ? -1 : 1
    );
    for (Item item : items) {
      int itemCount = go
        .getInventories()
        .getItemBag()
        .getItem(item.getItemId())
        .getCount();
      if (itemCount > 0) {
        String itemName = fixItemName(item.getItemId().name());
        Bot.class.getClassLoader();
        String imgsrc = ClassLoader
          .getSystemResource(
            "jPokéBotResources/images/items/" + item.getItemId() + ".png"
          )
          .toString();
        sb.append(
          "<tr><td>" +
          itemCount +
          "</td><td>x</td><td><img src=\"" +
          imgsrc +
          "\" width=\"10px\" height=\"10px\" /></td><td>" +
          itemName +
          "</td></tr>"
        );
      }
    }
    sb.append("</table></body></html>");
    return sb.toString();
  }

  public String fixItemName(String name) {
    String fixedName = name.replaceAll("ITEM_", "").toLowerCase();
    String[] nameParts = fixedName.split("_");
    StringBuilder sb = new StringBuilder();
    for (String s : nameParts) {
      sb.append(s.substring(0, 1).toUpperCase() + s.substring(1) + " ");
    }
    return sb.toString();
  }
}

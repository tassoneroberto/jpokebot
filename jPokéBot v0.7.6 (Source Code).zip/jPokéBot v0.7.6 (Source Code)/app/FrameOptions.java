package app;

import POGOProtos.Inventory.Item.ItemIdOuterClass.ItemId;
import com.pokegoapi.api.PokemonGo;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.HashMap;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JSlider;
import javax.swing.JTabbedPane;
import javax.swing.JTextField;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;

public class FrameOptions extends JFrame {

  private static final long serialVersionUID = 1L;

  private PokemonGo go;
  private JPanel panelMain;
  private JPanel panelPokestop, panelRename, panelPokemonCatch, panelRecycle, panelTransfer;
  private JTabbedPane tab;
  private JButton buttonSave;
  // RECYCLE
  private JPanel customBag;
  protected JCheckBox cActiveRecycle, cRecycleWhenFull, cKeepIncense, cKeepMasterball, cKeepLuckyEgg, cKeepTroyDisk;
  private JLabel lPotion, lSuperPotion, lHyperPotion, lMaxPotion, lRevive, lMaxRevive, lUnlimitedBasicIncubator, lPokeball, lMegaball, lUltraball, lMasterball, lLuckyEgg, lIncense, lTroyDisk, lRazzberry, lBasicIncubator;
  protected JTextField fPotion, fSuperPotion, fHyperPotion, fMaxPotion, fRevive, fMaxRevive, fUnlimitedBasicIncubator, fPokeball, fMegaball, fUltraball, fMasterball, fLuckyEgg, fIncense, fTroyDisk, fRazzberry, fBasicIncubator;
  private JLabel textCurrentConfig;
  private JTextField fCurrentConfig;
  private JLabel textMaxStorage;
  private JLabel textBagInputError;
  private JButton defaultRecycle;
  protected JComboBox<String> chooseDefaultRecycle;
  protected String recycleType = "";
  protected JCheckBox autoUpdate;
  // GENERAL
  protected JCheckBox cGetLevelReward;
  private JLabel lWidth, lTimeToCollect, lRescanTimeOut, lSpeed;
  protected JTextField fTimeToCollect, fRescanTimeOut, fSpeed;
  protected JComboBox<String> bWidth;
  private JLabel textPokestopInputError;
  // POKEMON CATCH
  private JPanel smartTransfer;
  private JPanel panelPokeball, panelBerry;
  protected JCheckBox cActiveCatch, cUseBerry, cUseMasterballOnLegendary, cLimitBerry, cLimitPokeball;
  protected JTextField fTimeOutCatch, fMaxBerry, fMaxPokeball;
  protected JComboBox<String> bUsePokeball, bDefaultPokeball;
  private JLabel lTimeOutCatch, lMaxBerry, lMaxPokeball;
  private JLabel textPokemonCatchInputError;
  // POKEMON TRANSFER
  protected JCheckBox cActiveTransfer, cMinCP, cMinIV, cFavorite, cPerfectMoves, cLegendary, cActiveSmartTransfer;
  protected JTextField fMinCP, fMinIV, fMinAverage, fMaxDuplicate;
  protected JButton balancePriority;
  protected JLabel lMaxDuplicate, lPriority, lMinAverage, lIV, lCP;
  protected JSlider prioritySlider;
  private JLabel textTransferInputError;

  // POKEMON TRANSFER
  protected JCheckBox cActiveRename, cRenameIV, cRenamePerfectMoves;

  private final int textFieldWidth = 50;
  private final int textFieldHeight = 20;
  private final int labelWidth = 200;
  private final int labelHeight = 20;
  private boolean errorPokestop, errorRecycle, errorPokemonCatch, errorTransfer;
  private JLabel settingsError;

  public FrameOptions(PokemonGo go) {
    this.go = go;
    this.setTitle("Options");
    int width = 450;
    int height = 450;
    this.setSize(width, height);
    this.setLocationRelativeTo(null);
    this.setLayout(null);
    this.setResizable(false);
    this.setDefaultCloseOperation(HIDE_ON_CLOSE);

    panelMain = new JPanel(null);
    this.add(panelMain);
    panelMain.setBounds(0, 0, width, height);

    // GENERAL OPTIONS
    panelPokestop = new JPanel(null);
    lWidth = new JLabel("Scan range");
    lTimeToCollect = new JLabel("Time to collect (s)");
    lRescanTimeOut = new JLabel("Time out rescan (s)");
    lSpeed = new JLabel("Movement speed (km/h)");
    cGetLevelReward = new JCheckBox("Get level reward");

    bWidth = new JComboBox<String>();
    for (int i = 1; i < 11; i++) bWidth.addItem("" + i);
    fTimeToCollect = new JTextField("3");
    fRescanTimeOut = new JTextField("10");
    fSpeed = new JTextField("60");

    panelPokestop.add(lWidth);
    panelPokestop.add(lTimeToCollect);
    panelPokestop.add(lRescanTimeOut);
    panelPokestop.add(lSpeed);
    panelPokestop.add(bWidth);
    panelPokestop.add(fTimeToCollect);
    panelPokestop.add(fRescanTimeOut);
    panelPokestop.add(fSpeed);
    panelPokestop.add(cGetLevelReward);

    bWidth.setBounds(10, 10, 60, 25);
    fTimeToCollect.setBounds(10, 40, 60, 20);
    fRescanTimeOut.setBounds(10, 70, 60, 20);
    fSpeed.setBounds(10, 100, 60, 20);

    lWidth.setBounds(80, 10, 180, 20);
    lTimeToCollect.setBounds(80, 40, 180, 20);
    lRescanTimeOut.setBounds(80, 70, 180, 20);
    lSpeed.setBounds(80, 100, 180, 20);
    cGetLevelReward.setBounds(10, 130, 200, 20);

    textPokestopInputError = new JLabel("");
    panelPokestop.add(textPokestopInputError);
    textPokestopInputError.setBounds(10, height - 120, 200, 20);

    fTimeToCollect
      .getDocument()
      .addDocumentListener(
        new DocumentListener() {
          @Override
          public void insertUpdate(DocumentEvent e) {
            checkPokestopInputData();
          }

          @Override
          public void removeUpdate(DocumentEvent e) {
            checkPokestopInputData();
          }

          @Override
          public void changedUpdate(DocumentEvent e) {
            checkPokestopInputData();
          }
        }
      );

    fRescanTimeOut
      .getDocument()
      .addDocumentListener(
        new DocumentListener() {
          @Override
          public void insertUpdate(DocumentEvent e) {
            checkPokestopInputData();
          }

          @Override
          public void removeUpdate(DocumentEvent e) {
            checkPokestopInputData();
          }

          @Override
          public void changedUpdate(DocumentEvent e) {
            checkPokestopInputData();
          }
        }
      );

    fSpeed
      .getDocument()
      .addDocumentListener(
        new DocumentListener() {
          @Override
          public void insertUpdate(DocumentEvent e) {
            checkPokestopInputData();
          }

          @Override
          public void removeUpdate(DocumentEvent e) {
            checkPokestopInputData();
          }

          @Override
          public void changedUpdate(DocumentEvent e) {
            checkPokestopInputData();
          }
        }
      );

    // RECYCLE OPTIONS
    panelRecycle = new JPanel(null);
    cActiveRecycle = new JCheckBox("Active item recycling", true);
    cRecycleWhenFull = new JCheckBox("Recycle only with full bag", true);
    cKeepIncense = new JCheckBox("Keep all Incense", true);
    cKeepLuckyEgg = new JCheckBox("Keep all Lucky Egg", true);
    cKeepMasterball = new JCheckBox("Keep all Masterball", true);
    cKeepTroyDisk = new JCheckBox("Keep all Lure Module", true);

    panelRecycle.add(cActiveRecycle);
    panelRecycle.add(cRecycleWhenFull);
    panelRecycle.add(cKeepIncense);
    panelRecycle.add(cKeepLuckyEgg);
    panelRecycle.add(cKeepMasterball);
    panelRecycle.add(cKeepTroyDisk);

    cActiveRecycle.setBounds(10, 5, (width - 50) / 2, 20);
    cKeepIncense.setBounds(10, 5 + 20 * 1, (width - 50) / 2, 20);
    cKeepMasterball.setBounds(10, 5 + 20 * 2, (width - 50) / 2, 20);

    cRecycleWhenFull.setBounds((width - 20) / 2, 5, (width - 50) / 2, 20);
    cKeepLuckyEgg.setBounds((width - 20) / 2, 5 + 20 * 1, (width - 50) / 2, 20);
    cKeepTroyDisk.setBounds((width - 20) / 2, 5 + 20 * 2, (width - 50) / 2, 20);

    customBag = new JPanel(null);
    panelRecycle.add(customBag);
    customBag.setBorder(
      BorderFactory.createTitledBorder(
        BorderFactory.createEtchedBorder(),
        "Custom Bag"
      )
    );
    customBag.setBounds(10, 70, width - 40, height - 170);

    fPokeball = new JTextField("0");
    fMegaball = new JTextField("0");
    fUltraball = new JTextField("0");
    fMasterball = new JTextField("∞");
    fMasterball.setEnabled(false);
    fLuckyEgg = new JTextField("∞");
    fLuckyEgg.setEnabled(false);
    fIncense = new JTextField("∞");
    fIncense.setEnabled(false);
    fTroyDisk = new JTextField("∞");
    fTroyDisk.setEnabled(false);
    fRazzberry = new JTextField("0");
    fPotion = new JTextField("0");
    fSuperPotion = new JTextField("0");
    fHyperPotion = new JTextField("0");
    fMaxPotion = new JTextField("0");
    fRevive = new JTextField("0");
    fMaxRevive = new JTextField("0");
    fUnlimitedBasicIncubator =
      new JTextField(
        "" +
        go
          .getInventories()
          .getItemBag()
          .getItem(ItemId.ITEM_INCUBATOR_BASIC_UNLIMITED)
          .getCount()
      );
    fUnlimitedBasicIncubator.setEnabled(false);
    fBasicIncubator =
      new JTextField(
        "" +
        go
          .getInventories()
          .getItemBag()
          .getItem(ItemId.ITEM_INCUBATOR_BASIC)
          .getCount()
      );
    fBasicIncubator.setEnabled(false);

    customBag.add(fPokeball);
    customBag.add(fMegaball);
    customBag.add(fUltraball);
    customBag.add(fMasterball);
    customBag.add(fLuckyEgg);
    customBag.add(fIncense);
    customBag.add(fTroyDisk);
    customBag.add(fRazzberry);
    customBag.add(fPotion);
    customBag.add(fSuperPotion);
    customBag.add(fHyperPotion);
    customBag.add(fMaxPotion);
    customBag.add(fRevive);
    customBag.add(fMaxRevive);
    customBag.add(fBasicIncubator);
    customBag.add(fUnlimitedBasicIncubator);

    textBagInputError = new JLabel("");
    customBag.add(textBagInputError);
    textBagInputError.setBounds(240, 25 + 7 * 5 + 8 * textFieldHeight, 220, 20);

    fPokeball
      .getDocument()
      .addDocumentListener(
        new DocumentListener() {
          @Override
          public void insertUpdate(DocumentEvent e) {
            changeToCustom();
          }

          @Override
          public void removeUpdate(DocumentEvent e) {
            changeToCustom();
          }

          @Override
          public void changedUpdate(DocumentEvent e) {
            changeToCustom();
          }
        }
      );

    fMegaball
      .getDocument()
      .addDocumentListener(
        new DocumentListener() {
          @Override
          public void insertUpdate(DocumentEvent e) {
            changeToCustom();
          }

          @Override
          public void removeUpdate(DocumentEvent e) {
            changeToCustom();
          }

          @Override
          public void changedUpdate(DocumentEvent e) {
            changeToCustom();
          }
        }
      );

    fUltraball
      .getDocument()
      .addDocumentListener(
        new DocumentListener() {
          @Override
          public void insertUpdate(DocumentEvent e) {
            changeToCustom();
          }

          @Override
          public void removeUpdate(DocumentEvent e) {
            changeToCustom();
          }

          @Override
          public void changedUpdate(DocumentEvent e) {
            changeToCustom();
          }
        }
      );

    fMasterball
      .getDocument()
      .addDocumentListener(
        new DocumentListener() {
          @Override
          public void insertUpdate(DocumentEvent e) {
            changeToCustom();
          }

          @Override
          public void removeUpdate(DocumentEvent e) {
            changeToCustom();
          }

          @Override
          public void changedUpdate(DocumentEvent e) {
            changeToCustom();
          }
        }
      );

    fLuckyEgg
      .getDocument()
      .addDocumentListener(
        new DocumentListener() {
          @Override
          public void insertUpdate(DocumentEvent e) {
            changeToCustom();
          }

          @Override
          public void removeUpdate(DocumentEvent e) {
            changeToCustom();
          }

          @Override
          public void changedUpdate(DocumentEvent e) {
            changeToCustom();
          }
        }
      );

    fIncense
      .getDocument()
      .addDocumentListener(
        new DocumentListener() {
          @Override
          public void insertUpdate(DocumentEvent e) {
            changeToCustom();
          }

          @Override
          public void removeUpdate(DocumentEvent e) {
            changeToCustom();
          }

          @Override
          public void changedUpdate(DocumentEvent e) {
            changeToCustom();
          }
        }
      );

    fTroyDisk
      .getDocument()
      .addDocumentListener(
        new DocumentListener() {
          @Override
          public void insertUpdate(DocumentEvent e) {
            changeToCustom();
          }

          @Override
          public void removeUpdate(DocumentEvent e) {
            changeToCustom();
          }

          @Override
          public void changedUpdate(DocumentEvent e) {
            changeToCustom();
          }
        }
      );

    fRazzberry
      .getDocument()
      .addDocumentListener(
        new DocumentListener() {
          @Override
          public void insertUpdate(DocumentEvent e) {
            changeToCustom();
          }

          @Override
          public void removeUpdate(DocumentEvent e) {
            changeToCustom();
          }

          @Override
          public void changedUpdate(DocumentEvent e) {
            changeToCustom();
          }
        }
      );

    fPotion
      .getDocument()
      .addDocumentListener(
        new DocumentListener() {
          @Override
          public void insertUpdate(DocumentEvent e) {
            changeToCustom();
          }

          @Override
          public void removeUpdate(DocumentEvent e) {
            changeToCustom();
          }

          @Override
          public void changedUpdate(DocumentEvent e) {
            changeToCustom();
          }
        }
      );

    fSuperPotion
      .getDocument()
      .addDocumentListener(
        new DocumentListener() {
          @Override
          public void insertUpdate(DocumentEvent e) {
            changeToCustom();
          }

          @Override
          public void removeUpdate(DocumentEvent e) {
            changeToCustom();
          }

          @Override
          public void changedUpdate(DocumentEvent e) {
            changeToCustom();
          }
        }
      );

    fHyperPotion
      .getDocument()
      .addDocumentListener(
        new DocumentListener() {
          @Override
          public void insertUpdate(DocumentEvent e) {
            changeToCustom();
          }

          @Override
          public void removeUpdate(DocumentEvent e) {
            changeToCustom();
          }

          @Override
          public void changedUpdate(DocumentEvent e) {
            changeToCustom();
          }
        }
      );

    fMaxPotion
      .getDocument()
      .addDocumentListener(
        new DocumentListener() {
          @Override
          public void insertUpdate(DocumentEvent e) {
            changeToCustom();
          }

          @Override
          public void removeUpdate(DocumentEvent e) {
            changeToCustom();
          }

          @Override
          public void changedUpdate(DocumentEvent e) {
            changeToCustom();
          }
        }
      );

    fRevive
      .getDocument()
      .addDocumentListener(
        new DocumentListener() {
          @Override
          public void insertUpdate(DocumentEvent e) {
            changeToCustom();
          }

          @Override
          public void removeUpdate(DocumentEvent e) {
            changeToCustom();
          }

          @Override
          public void changedUpdate(DocumentEvent e) {
            changeToCustom();
          }
        }
      );

    fMaxRevive
      .getDocument()
      .addDocumentListener(
        new DocumentListener() {
          @Override
          public void insertUpdate(DocumentEvent e) {
            changeToCustom();
          }

          @Override
          public void removeUpdate(DocumentEvent e) {
            changeToCustom();
          }

          @Override
          public void changedUpdate(DocumentEvent e) {
            changeToCustom();
          }
        }
      );

    fPokeball.setBounds(
      10,
      20 + 0 * 5 + 0 * textFieldHeight,
      textFieldWidth,
      textFieldHeight
    );
    fMegaball.setBounds(
      10,
      20 + 1 * 5 + 1 * textFieldHeight,
      textFieldWidth,
      textFieldHeight
    );
    fUltraball.setBounds(
      10,
      20 + 2 * 5 + 2 * textFieldHeight,
      textFieldWidth,
      textFieldHeight
    );
    fMasterball.setBounds(
      10,
      20 + 3 * 5 + 3 * textFieldHeight,
      textFieldWidth,
      textFieldHeight
    );
    fLuckyEgg.setBounds(
      10,
      20 + 4 * 5 + 4 * textFieldHeight,
      textFieldWidth,
      textFieldHeight
    );
    fIncense.setBounds(
      10,
      20 + 5 * 5 + 5 * textFieldHeight,
      textFieldWidth,
      textFieldHeight
    );
    fTroyDisk.setBounds(
      10,
      20 + 6 * 5 + 6 * textFieldHeight,
      textFieldWidth,
      textFieldHeight
    );
    fRazzberry.setBounds(
      10,
      20 + 7 * 5 + 7 * textFieldHeight,
      textFieldWidth,
      textFieldHeight
    );
    fPotion.setBounds(
      (width - 20) / 2,
      20 + 0 * 5 + 0 * textFieldHeight,
      textFieldWidth,
      textFieldHeight
    );
    fSuperPotion.setBounds(
      (width - 20) / 2,
      20 + 1 * 5 + 1 * textFieldHeight,
      textFieldWidth,
      textFieldHeight
    );
    fHyperPotion.setBounds(
      (width - 20) / 2,
      20 + 2 * 5 + 2 * textFieldHeight,
      textFieldWidth,
      textFieldHeight
    );
    fMaxPotion.setBounds(
      (width - 20) / 2,
      20 + 3 * 5 + 3 * textFieldHeight,
      textFieldWidth,
      textFieldHeight
    );
    fRevive.setBounds(
      (width - 20) / 2,
      20 + 4 * 5 + 4 * textFieldHeight,
      textFieldWidth,
      textFieldHeight
    );
    fMaxRevive.setBounds(
      (width - 20) / 2,
      20 + 5 * 5 + 5 * textFieldHeight,
      textFieldWidth,
      textFieldHeight
    );
    fBasicIncubator.setBounds(
      (width - 20) / 2,
      20 + 6 * 5 + 6 * textFieldHeight,
      textFieldWidth,
      textFieldHeight
    );
    fUnlimitedBasicIncubator.setBounds(
      (width - 20) / 2,
      20 + 7 * 5 + 7 * textFieldHeight,
      textFieldWidth,
      textFieldHeight
    );

    lPokeball = new JLabel("Pokéball");
    lMegaball = new JLabel("Megaball");
    lUltraball = new JLabel("Ultraball");
    lMasterball = new JLabel("Masterball");
    lLuckyEgg = new JLabel("Lucky Egg");
    lIncense = new JLabel("Incense");
    lTroyDisk = new JLabel("Lure Module");
    lRazzberry = new JLabel("RazzBerry");
    lPotion = new JLabel("Potion");
    lSuperPotion = new JLabel("Super Potion");
    lHyperPotion = new JLabel("Hyper Potion");
    lMaxPotion = new JLabel("Max Potion");
    lRevive = new JLabel("Revive");
    lMaxRevive = new JLabel("Max Revive");
    lBasicIncubator = new JLabel("Basic Incubator");
    lUnlimitedBasicIncubator = new JLabel("Basic ∞Incubator");

    customBag.add(lPokeball);
    customBag.add(lMegaball);
    customBag.add(lUltraball);
    customBag.add(lMasterball);
    customBag.add(lLuckyEgg);
    customBag.add(lIncense);
    customBag.add(lTroyDisk);
    customBag.add(lRazzberry);
    customBag.add(lPotion);
    customBag.add(lSuperPotion);
    customBag.add(lHyperPotion);
    customBag.add(lMaxPotion);
    customBag.add(lRevive);
    customBag.add(lMaxRevive);
    customBag.add(lBasicIncubator);
    customBag.add(lUnlimitedBasicIncubator);

    lPokeball.setBounds(
      10 + textFieldWidth,
      20 + 0 * 5 + 0 * textFieldHeight,
      labelWidth,
      labelHeight
    );
    lMegaball.setBounds(
      10 + textFieldWidth,
      20 + 1 * 5 + 1 * textFieldHeight,
      labelWidth,
      labelHeight
    );
    lUltraball.setBounds(
      10 + textFieldWidth,
      20 + 2 * 5 + 2 * textFieldHeight,
      labelWidth,
      labelHeight
    );
    lMasterball.setBounds(
      10 + textFieldWidth,
      20 + 3 * 5 + 3 * textFieldHeight,
      labelWidth,
      labelHeight
    );
    lLuckyEgg.setBounds(
      10 + textFieldWidth,
      20 + 4 * 5 + 4 * textFieldHeight,
      labelWidth,
      labelHeight
    );
    lIncense.setBounds(
      10 + textFieldWidth,
      20 + 5 * 5 + 5 * textFieldHeight,
      labelWidth,
      labelHeight
    );
    lTroyDisk.setBounds(
      10 + textFieldWidth,
      20 + 6 * 5 + 6 * textFieldHeight,
      labelWidth,
      labelHeight
    );
    lRazzberry.setBounds(
      10 + textFieldWidth,
      20 + 7 * 5 + 7 * textFieldHeight,
      labelWidth,
      labelHeight
    );
    lPotion.setBounds(
      (width - 20) / 2 + textFieldWidth,
      20 + 0 * 5 + 0 * textFieldHeight,
      labelWidth,
      labelHeight
    );
    lSuperPotion.setBounds(
      (width - 20) / 2 + textFieldWidth,
      20 + 1 * 5 + 1 * textFieldHeight,
      labelWidth,
      labelHeight
    );
    lHyperPotion.setBounds(
      (width - 20) / 2 + textFieldWidth,
      20 + 2 * 5 + 2 * textFieldHeight,
      labelWidth,
      labelHeight
    );
    lMaxPotion.setBounds(
      (width - 20) / 2 + textFieldWidth,
      20 + 3 * 5 + 3 * textFieldHeight,
      labelWidth,
      labelHeight
    );
    lRevive.setBounds(
      (width - 20) / 2 + textFieldWidth,
      20 + 4 * 5 + 4 * textFieldHeight,
      labelWidth,
      labelHeight
    );
    lMaxRevive.setBounds(
      (width - 20) / 2 + textFieldWidth,
      20 + 5 * 5 + 5 * textFieldHeight,
      labelWidth,
      labelHeight
    );
    lBasicIncubator.setBounds(
      (width - 20) / 2 + textFieldWidth,
      20 + 6 * 5 + 6 * textFieldHeight,
      labelWidth,
      labelHeight
    );
    lUnlimitedBasicIncubator.setBounds(
      (width - 20) / 2 + textFieldWidth,
      20 + 7 * 5 + 7 * textFieldHeight,
      labelWidth,
      labelHeight
    );

    cActiveRecycle.addActionListener(
      new ActionListener() {
        public void actionPerformed(ActionEvent e) {
          if (cActiveRecycle.isSelected()) {
            enableItemRecycleButtons();
          } else {
            disableItemRecycleButtons();
          }
        }
      }
    );

    cKeepMasterball.addActionListener(
      new ActionListener() {
        public void actionPerformed(ActionEvent e) {
          if (cKeepMasterball.isSelected()) {
            fMasterball.setEnabled(false);
            fMasterball.setText("∞");
          } else {
            fMasterball.setEnabled(true);
            fMasterball.setText("0");
          }
        }
      }
    );

    cKeepLuckyEgg.addActionListener(
      new ActionListener() {
        public void actionPerformed(ActionEvent e) {
          if (cKeepLuckyEgg.isSelected()) {
            fLuckyEgg.setEnabled(false);
            fLuckyEgg.setText("∞");
          } else {
            fLuckyEgg.setEnabled(true);
            fLuckyEgg.setText("0");
          }
        }
      }
    );

    cKeepIncense.addActionListener(
      new ActionListener() {
        public void actionPerformed(ActionEvent e) {
          if (cKeepIncense.isSelected()) {
            fIncense.setEnabled(false);
            fIncense.setText("∞");
          } else {
            fIncense.setEnabled(true);
            fIncense.setText("0");
          }
        }
      }
    );

    cKeepTroyDisk.addActionListener(
      new ActionListener() {
        public void actionPerformed(ActionEvent e) {
          if (cKeepTroyDisk.isSelected()) {
            fTroyDisk.setEnabled(false);
            fTroyDisk.setText("∞");
          } else {
            fTroyDisk.setEnabled(true);
            fTroyDisk.setText("0");
          }
        }
      }
    );

    textCurrentConfig = new JLabel("Current configuration:");
    textMaxStorage =
      new JLabel(
        "/" + go.getPlayerProfile().getPlayerData().getMaxItemStorage()
      );
    fCurrentConfig = new JTextField("");
    fCurrentConfig.setEditable(false);

    customBag.add(textCurrentConfig);
    customBag.add(textMaxStorage);
    customBag.add(fCurrentConfig);

    textCurrentConfig.setBounds(10, 25 + 7 * 5 + 8 * textFieldHeight, 150, 20);
    fCurrentConfig.setBounds(
      10 + 140,
      25 + 7 * 5 + 8 * textFieldHeight,
      40,
      20
    );
    textMaxStorage.setBounds(
      10 + 180,
      25 + 7 * 5 + 8 * textFieldHeight,
      50,
      20
    );

    defaultRecycle = new JButton("Set default kit");
    chooseDefaultRecycle = new JComboBox<String>();
    chooseDefaultRecycle.addItem("Balanced");
    chooseDefaultRecycle.addItem("Pokémon Catcher");
    chooseDefaultRecycle.addItem("Gym Fighter");
    chooseDefaultRecycle.addItem("Custom");

    autoUpdate = new JCheckBox("Auto update");

    customBag.add(defaultRecycle);
    customBag.add(chooseDefaultRecycle);
    customBag.add(autoUpdate);

    defaultRecycle.setBounds(10, 25 + 8 * 5 + 9 * textFieldHeight, 120, 20);
    chooseDefaultRecycle.setBounds(
      10 + 120 + 5,
      23 + 8 * 5 + 9 * textFieldHeight,
      160,
      25
    );
    autoUpdate.setBounds(
      10 + 120 + 160,
      25 + 8 * 5 + 9 * textFieldHeight,
      110,
      20
    );

    defaultRecycle.addActionListener(
      new ActionListener() {
        public void actionPerformed(ActionEvent e) {
          recycleType =
            chooseDefaultRecycle.getItemAt(
              chooseDefaultRecycle.getSelectedIndex()
            );
          setDefaultRecycle(go);
        }
      }
    );

    // POKEMON TRANSFER OPTIONS
    panelTransfer = new JPanel(null);

    cActiveTransfer = new JCheckBox("Active Pokémon transfer");
    fMaxDuplicate = new JTextField();
    lMaxDuplicate = new JLabel("Max duplicate");
    cFavorite = new JCheckBox("Never transfer favorites");
    cLegendary = new JCheckBox("Never transfer legendaries");
    cPerfectMoves = new JCheckBox("Never transfer with perfect moves");
    cMinCP = new JCheckBox("Never transfer over CP");
    fMinCP = new JTextField();
    cMinIV = new JCheckBox("Never transfer over IV (%)");
    fMinIV = new JTextField();
    cActiveSmartTransfer = new JCheckBox("Active smart transfer");
    lPriority = new JLabel("Set your priority:");
    balancePriority = new JButton("Reset");
    fMinAverage = new JTextField();
    lMinAverage = new JLabel("Keep min average (%)");
    prioritySlider = new JSlider();
    lIV = new JLabel("IV");
    lCP = new JLabel("CP");

    smartTransfer = new JPanel(null);
    panelTransfer.add(smartTransfer);
    smartTransfer.setBorder(
      BorderFactory.createTitledBorder(
        BorderFactory.createEtchedBorder(),
        "Smart Transfer"
      )
    );

    smartTransfer.add(cActiveSmartTransfer);
    smartTransfer.add(fMinAverage);
    smartTransfer.add(lMinAverage);
    smartTransfer.add(balancePriority);
    smartTransfer.add(lPriority);
    smartTransfer.add(lIV);
    smartTransfer.add(prioritySlider);
    smartTransfer.add(lCP);

    cActiveSmartTransfer.setBounds(10, 20, 200, 20);
    lMinAverage.setBounds(width - 230, 20, 200, 20);
    fMinAverage.setBounds(width - 90, 20, 40, 20);
    balancePriority.setBounds(width - 155, 50, 100, 20);
    lPriority.setBounds(10, 50, 300, 20);
    lIV.setBounds(10, 75, 30, 20);
    prioritySlider.setBounds(20, 75, width - 90, 20);
    lCP.setBounds(width - 70, 75, 30, 20);

    panelTransfer.add(cActiveTransfer);
    panelTransfer.add(fMaxDuplicate);
    panelTransfer.add(lMaxDuplicate);
    panelTransfer.add(cFavorite);
    panelTransfer.add(cLegendary);
    panelTransfer.add(cPerfectMoves);
    panelTransfer.add(cMinCP);
    panelTransfer.add(fMinCP);
    panelTransfer.add(cMinIV);
    panelTransfer.add(fMinIV);
    panelTransfer.add(smartTransfer);

    cActiveTransfer.setBounds(10, 10, 200, 20);
    fMaxDuplicate.setBounds((width - 20) / 2, 10, 50, 20);
    lMaxDuplicate.setBounds(((width - 20) / 2) + 60, 10, 200, 20);
    cFavorite.setBounds(10, 40, 200, 20);
    cLegendary.setBounds(10, 70, 200, 20);
    cPerfectMoves.setBounds(10, 100, 400, 20);
    cMinCP.setBounds(10, 130, 200, 20);
    fMinCP.setBounds(210, 130, 50, 20);
    cMinIV.setBounds(10, 160, 200, 20);
    fMinIV.setBounds(210, 160, 50, 20);
    smartTransfer.setBounds(10, 190, width - 40, 110);

    cActiveTransfer.addActionListener(
      new ActionListener() {
        public void actionPerformed(ActionEvent e) {
          if (
            cActiveTransfer.isSelected()
          ) enablePokemonTransferButtons(); else disablePokemonTransferButtons();
        }
      }
    );

    cActiveSmartTransfer.addActionListener(
      new ActionListener() {
        public void actionPerformed(ActionEvent e) {
          if (cActiveSmartTransfer.isSelected()) {
            if (prioritySlider.getValue() != 50) balancePriority.setEnabled(
              true
            );
            prioritySlider.setEnabled(true);
            fMinAverage.setEnabled(true);
          } else {
            balancePriority.setEnabled(false);
            prioritySlider.setEnabled(false);
            fMinAverage.setEnabled(false);
          }
        }
      }
    );

    cMinCP.addActionListener(
      new ActionListener() {
        public void actionPerformed(ActionEvent e) {
          if (cMinCP.isSelected()) fMinCP.setEnabled(
            true
          ); else fMinCP.setEnabled(false);
        }
      }
    );

    cMinIV.addActionListener(
      new ActionListener() {
        public void actionPerformed(ActionEvent e) {
          if (cMinIV.isSelected()) fMinIV.setEnabled(
            true
          ); else fMinIV.setEnabled(false);
        }
      }
    );

    balancePriority.addActionListener(
      new ActionListener() {
        public void actionPerformed(ActionEvent e) {
          prioritySlider.setValue(50);
          balancePriority.setEnabled(false);
        }
      }
    );

    prioritySlider.addChangeListener(
      new ChangeListener() {
        @Override
        public void stateChanged(ChangeEvent e) {
          balancePriority.setEnabled(true);
          lPriority.setText(
            "Set your priority: [IV " +
            prioritySlider.getValue() +
            "%] [CP " +
            (100 - prioritySlider.getValue()) +
            "%]"
          );
        }
      }
    );

    fMaxDuplicate
      .getDocument()
      .addDocumentListener(
        new DocumentListener() {
          @Override
          public void insertUpdate(DocumentEvent e) {
            checkPokemonTransferInputData();
          }

          @Override
          public void removeUpdate(DocumentEvent e) {
            checkPokemonTransferInputData();
          }

          @Override
          public void changedUpdate(DocumentEvent e) {
            checkPokemonTransferInputData();
          }
        }
      );

    fMinCP
      .getDocument()
      .addDocumentListener(
        new DocumentListener() {
          @Override
          public void insertUpdate(DocumentEvent e) {
            checkPokemonTransferInputData();
          }

          @Override
          public void removeUpdate(DocumentEvent e) {
            checkPokemonTransferInputData();
          }

          @Override
          public void changedUpdate(DocumentEvent e) {
            checkPokemonTransferInputData();
          }
        }
      );

    fMinIV
      .getDocument()
      .addDocumentListener(
        new DocumentListener() {
          @Override
          public void insertUpdate(DocumentEvent e) {
            checkPokemonTransferInputData();
          }

          @Override
          public void removeUpdate(DocumentEvent e) {
            checkPokemonTransferInputData();
          }

          @Override
          public void changedUpdate(DocumentEvent e) {
            checkPokemonTransferInputData();
          }
        }
      );

    fMinAverage
      .getDocument()
      .addDocumentListener(
        new DocumentListener() {
          @Override
          public void insertUpdate(DocumentEvent e) {
            checkPokemonTransferInputData();
          }

          @Override
          public void removeUpdate(DocumentEvent e) {
            checkPokemonTransferInputData();
          }

          @Override
          public void changedUpdate(DocumentEvent e) {
            checkPokemonTransferInputData();
          }
        }
      );

    textTransferInputError = new JLabel("");
    panelTransfer.add(textTransferInputError);
    textTransferInputError.setBounds(10, height - 120, 300, 20);

    // RENAME OPTIONS
    panelRename = new JPanel(null);

    cActiveRename = new JCheckBox("Active Pokémon rename");
    cRenameIV = new JCheckBox("Add Pokémon IV");
    cRenamePerfectMoves =
      new JCheckBox(
        "Add perfect moves symbols: 1°=\"¹\" | 2°=\"²\" | both=\"¤\""
      );

    panelRename.add(cActiveRename);
    panelRename.add(cRenameIV);
    panelRename.add(cRenamePerfectMoves);

    cActiveRename.setBounds(10, 10, 200, 20);
    cRenameIV.setBounds(10, 40, 200, 20);
    cRenamePerfectMoves.setBounds(10, 70, 400, 20);

    cActiveRename.addActionListener(
      new ActionListener() {
        public void actionPerformed(ActionEvent e) {
          if (
            cActiveRename.isSelected()
          ) enablePokemonRenameButtons(); else disablePokemonRenameButtons();
        }
      }
    );

    // POKEMON CATCH OPTIONS
    panelPokemonCatch = new JPanel(null);

    cActiveCatch = new JCheckBox("Active Pokémon catching");
    fTimeOutCatch = new JTextField("3");
    lTimeOutCatch = new JLabel("Wait after catch (s)");
    cUseBerry = new JCheckBox("Use RazzBerry");
    cUseMasterballOnLegendary = new JCheckBox("Use Masterball on legendary");
    bUsePokeball = new JComboBox<String>();
    bUsePokeball.addItem("Smart Pokéball selection");
    bUsePokeball.addItem("Best Pokéball selection");
    bUsePokeball.addItem("Default Pokéball selection");
    bDefaultPokeball = new JComboBox<String>();
    bDefaultPokeball.addItem("Pokéball");
    bDefaultPokeball.addItem("Megaball");
    bDefaultPokeball.addItem("Ultraball");
    bDefaultPokeball.addItem("Masterball");
    cLimitBerry = new JCheckBox("Limit RazzBerry used");
    cLimitPokeball = new JCheckBox("Limit Pokeball used");
    fMaxBerry = new JTextField("0");
    lMaxBerry = new JLabel("Max RazzBerry to use");
    fMaxPokeball = new JTextField("0");
    lMaxPokeball = new JLabel("Max Pokéball to use");

    panelPokeball = new JPanel(null);
    panelPokemonCatch.add(panelPokeball);
    panelPokeball.setBorder(
      BorderFactory.createTitledBorder(
        BorderFactory.createEtchedBorder(),
        "Pokéball"
      )
    );

    panelBerry = new JPanel(null);
    panelPokemonCatch.add(panelBerry);
    panelBerry.setBorder(
      BorderFactory.createTitledBorder(
        BorderFactory.createEtchedBorder(),
        "RazzBerry"
      )
    );

    panelPokemonCatch.add(cActiveCatch);
    panelPokemonCatch.add(fTimeOutCatch);
    panelPokemonCatch.add(lTimeOutCatch);
    panelPokemonCatch.add(cUseMasterballOnLegendary);

    panelPokeball.add(bUsePokeball);
    panelPokeball.add(bDefaultPokeball);
    panelPokeball.add(cLimitPokeball);
    panelPokeball.add(fMaxPokeball);
    panelPokeball.add(lMaxPokeball);

    panelBerry.add(cUseBerry);
    panelBerry.add(cLimitBerry);
    panelBerry.add(fMaxBerry);
    panelBerry.add(lMaxBerry);

    cActiveCatch.setBounds(10, 10, 200, 20);
    fTimeOutCatch.setBounds(((width - 20) / 2) + 10, 10, 40, 20);
    lTimeOutCatch.setBounds(((width - 20) / 2) + 60, 10, 150, 20);
    cUseMasterballOnLegendary.setBounds(10, 40, 250, 20);

    panelPokeball.setBounds(10, 70, width - 40, 90);
    bUsePokeball.setBounds(10, 20, 250, 25);
    bDefaultPokeball.setBounds(260, 20, 140, 25);
    cLimitPokeball.setBounds(10, 55, 180, 20);
    fMaxPokeball.setBounds(190, 55, 50, 20);
    lMaxPokeball.setBounds(240, 55, 140, 20);

    panelBerry.setBounds(10, 160, width - 40, 90);
    cUseBerry.setBounds(10, 20, 200, 20);
    cLimitBerry.setBounds(10, 50, 180, 20);
    fMaxBerry.setBounds(190, 50, 50, 20);
    lMaxBerry.setBounds(240, 50, 140, 20);

    textPokemonCatchInputError = new JLabel("");
    panelPokemonCatch.add(textPokemonCatchInputError);
    textPokemonCatchInputError.setBounds(10, height - 120, 200, 20);

    cActiveCatch.addActionListener(
      new ActionListener() {
        public void actionPerformed(ActionEvent e) {
          if (
            cActiveCatch.isSelected()
          ) enablePokemonCatchButtons(); else disablePokemonCatchButtons();
        }
      }
    );

    bUsePokeball.addActionListener(
      new ActionListener() {
        public void actionPerformed(ActionEvent e) {
          if (bUsePokeball.getSelectedIndex() == 2) bDefaultPokeball.setEnabled(
            true
          ); else bDefaultPokeball.setEnabled(false);
        }
      }
    );

    cLimitPokeball.addActionListener(
      new ActionListener() {
        public void actionPerformed(ActionEvent e) {
          if (cLimitPokeball.isSelected()) fMaxPokeball.setEnabled(
            true
          ); else fMaxPokeball.setEnabled(false);
        }
      }
    );

    cUseBerry.addActionListener(
      new ActionListener() {
        public void actionPerformed(ActionEvent e) {
          if (cUseBerry.isSelected()) {
            cLimitBerry.setEnabled(true);
            if (cLimitBerry.isSelected()) fMaxBerry.setEnabled(
              true
            ); else fMaxBerry.setEnabled(false);
          } else {
            cLimitBerry.setEnabled(false);
            fMaxBerry.setEnabled(false);
          }
        }
      }
    );

    cLimitBerry.addActionListener(
      new ActionListener() {
        public void actionPerformed(ActionEvent e) {
          if (cLimitBerry.isSelected()) fMaxBerry.setEnabled(
            true
          ); else fMaxBerry.setEnabled(false);
        }
      }
    );

    fTimeOutCatch
      .getDocument()
      .addDocumentListener(
        new DocumentListener() {
          @Override
          public void insertUpdate(DocumentEvent e) {
            checkPokemonCatchInputData();
          }

          @Override
          public void removeUpdate(DocumentEvent e) {
            checkPokemonCatchInputData();
          }

          @Override
          public void changedUpdate(DocumentEvent e) {
            checkPokemonCatchInputData();
          }
        }
      );

    fMaxBerry
      .getDocument()
      .addDocumentListener(
        new DocumentListener() {
          @Override
          public void insertUpdate(DocumentEvent e) {
            checkPokemonCatchInputData();
          }

          @Override
          public void removeUpdate(DocumentEvent e) {
            checkPokemonCatchInputData();
          }

          @Override
          public void changedUpdate(DocumentEvent e) {
            checkPokemonCatchInputData();
          }
        }
      );

    fMaxPokeball
      .getDocument()
      .addDocumentListener(
        new DocumentListener() {
          @Override
          public void insertUpdate(DocumentEvent e) {
            checkPokemonCatchInputData();
          }

          @Override
          public void removeUpdate(DocumentEvent e) {
            checkPokemonCatchInputData();
          }

          @Override
          public void changedUpdate(DocumentEvent e) {
            checkPokemonCatchInputData();
          }
        }
      );

    // TAB
    tab = new JTabbedPane();
    tab.addTab("Pokéstop Loot", panelPokestop);
    tab.addTab("Pokémon Catch", panelPokemonCatch);
    tab.addTab("Pokémon Transfer", panelTransfer);
    tab.addTab("Pokémon Rename", panelRename);
    tab.addTab("Item Recycle", panelRecycle);

    tab.setSelectedIndex(0);

    panelMain.add(tab);
    tab.setBounds(0, 0, width, height - 50);

    settingsError = new JLabel("");
    panelMain.add(settingsError);
    settingsError.setBounds(10, height - 50, width, 20);

    buttonSave = new JButton("Save");
    panelMain.add(buttonSave);
    buttonSave.setBounds(width - 110, height - 50, 100, 20);

    buttonSave.addActionListener(
      new ActionListener() {
        public void actionPerformed(ActionEvent e) {
          saveSettings();
          setVisible(false);
        }
      }
    );
  }

  protected void saveSettings() {
    saveGeneralSettings();
    savePokemonCatchSettings();
    savePokemonRenameSettings();
    savePokemonTransferSettings();
    saveRecycleItemsSettings();
  }

  private void settingsError(String tab) {
    settingsError.setText("* Error in " + tab + " settings.");
    buttonSave.setEnabled(false);
  }

  private void checkTotalSettingsError() {
    if (
      !errorPokestop && !errorRecycle && !errorPokemonCatch && !errorTransfer
    ) {
      settingsError.setText("");
      buttonSave.setEnabled(true);
    } else if (errorPokestop) {
      settingsError.setText("* Error in POKESTOP settings");
    } else if (errorRecycle) {
      settingsError.setText("* Error in ITEM RECYCLE settings");
    } else if (errorPokemonCatch) {
      settingsError.setText("* Error in POKEMON CATCH settings");
    } else if (errorTransfer) {
      settingsError.setText("* Error in TRANSFER settings");
    }
  }

  protected void checkPokestopInputData() {
    errorPokestop = false;
    try {
      int timeToCollect = Integer.parseInt(fTimeToCollect.getText());
      if (timeToCollect < 0) errorPokestop = true;
      int speed = Integer.parseInt(fTimeToCollect.getText());
      if (speed < 0) errorPokestop = true;
      int rescanTimeOut = Integer.parseInt(fRescanTimeOut.getText());
      if (rescanTimeOut < 0) errorPokestop = true;
    } catch (NumberFormatException e) {
      errorPokestop = true;
    }
    if (errorPokestop) {
      settingsError("POKESTOP");
      textPokestopInputError.setText("Only positive integer allowed!");
    } else {
      checkTotalSettingsError();
      textPokestopInputError.setText("");
    }
  }

  protected void checkPokemonCatchInputData() {
    errorPokemonCatch = false;
    try {
      int timeOutCatch = Integer.parseInt(fTimeOutCatch.getText());
      if (timeOutCatch < 0) errorPokemonCatch = true;
      int maxBerry = Integer.parseInt(fMaxBerry.getText());
      if (maxBerry < 0) errorPokemonCatch = true;
      int maxPokeball = Integer.parseInt(fMaxPokeball.getText());
      if (maxPokeball < 0) errorPokemonCatch = true;
    } catch (NumberFormatException e) {
      errorPokemonCatch = true;
    }
    if (errorPokemonCatch) {
      settingsError("POKEMON CATCH");
      textPokemonCatchInputError.setText("Only positive integer allowed!");
    } else {
      checkTotalSettingsError();
      textPokemonCatchInputError.setText("");
    }
  }

  protected void checkPokemonTransferInputData() {
    errorTransfer = false;
    boolean wrongInput = false;
    try {
      int maxDuplicate = Integer.parseInt(fMaxDuplicate.getText());
      if (maxDuplicate <= 0) {
        errorTransfer = true;
        textTransferInputError.setText("Max duplicate must be greater than 0!");
      }
      int minCP = Integer.parseInt(fMinCP.getText());
      if (minCP < 0) {
        errorTransfer = true;
        textTransferInputError.setText("Min CP must be positive!");
      }
      int minIV = Integer.parseInt(fMinIV.getText());
      if (minIV <= 0 || minIV > 100) {
        textTransferInputError.setText("IV must be included in 1-100!");
        errorTransfer = true;
      }
      int minAverage = Integer.parseInt(fMinAverage.getText());
      if (minAverage <= 0 || minAverage > 100) {
        textTransferInputError.setText(
          "Min Average must be included in 1-100!"
        );
        errorTransfer = true;
      }
    } catch (NumberFormatException e) {
      errorTransfer = true;
      wrongInput = true;
    }
    if (errorTransfer) {
      settingsError("POKEMON TRANSFER");
      if (wrongInput) {
        textTransferInputError.setText("Only positive integer allowed!");
      }
    } else {
      checkTotalSettingsError();
      textTransferInputError.setText("");
    }
  }

  private void saveGeneralSettings() {
    StringBuilder sb = new StringBuilder();
    sb.append(
      "jPokéBot - GENERAL SETTINGS" +
      System.lineSeparator() +
      System.lineSeparator()
    );
    sb.append("width=" + bWidth.getSelectedItem() + System.lineSeparator());
    sb.append(
      "timeToCollect=" + fTimeToCollect.getText() + System.lineSeparator()
    );
    sb.append(
      "rescanTimeOut=" + fRescanTimeOut.getText() + System.lineSeparator()
    );
    sb.append("speed=" + fSpeed.getText() + "\n");
    sb.append("getLevelReward=" + cGetLevelReward.isSelected());
    File settingsDataFile = new File("jPokéBotResources/settingsGeneral.txt");

    FileWriter fw;
    try {
      fw = new FileWriter(settingsDataFile.getAbsoluteFile());
      BufferedWriter bw = new BufferedWriter(fw);
      bw.write(sb.toString());
      bw.close();
    } catch (IOException e) {
      e.printStackTrace();
    }
  }

  private void savePokemonCatchSettings() {
    StringBuilder sb = new StringBuilder();
    sb.append(
      "jPokéBot - POKESTOP" + System.lineSeparator() + System.lineSeparator()
    );
    sb.append("active=" + cActiveCatch.isSelected() + System.lineSeparator());
    sb.append(
      "timeOutCatch=" + fTimeOutCatch.getText() + System.lineSeparator()
    );
    sb.append("useBerry=" + cUseBerry.isSelected() + System.lineSeparator());
    sb.append(
      "useMasterballOnLegendary=" +
      cUseMasterballOnLegendary.isSelected() +
      System.lineSeparator()
    );
    String pokeballToUse = "smart";
    if (bUsePokeball.getSelectedIndex() == 0) pokeballToUse = "smart"; else if (
      bUsePokeball.getSelectedIndex() == 1
    ) pokeballToUse = "best"; else if (
      bUsePokeball.getSelectedIndex() == 2
    ) pokeballToUse = "custom";
    sb.append("pokeballToUse=" + pokeballToUse + System.lineSeparator());
    sb.append(
      "defaultPokeball=" +
      bDefaultPokeball.getSelectedItem() +
      System.lineSeparator()
    );
    sb.append(
      "limitBerryUsed=" + cLimitBerry.isSelected() + System.lineSeparator()
    );
    sb.append("maxBerryUsed=" + fMaxBerry.getText() + System.lineSeparator());
    sb.append(
      "limitPokeballUsed=" +
      cLimitPokeball.isSelected() +
      System.lineSeparator()
    );
    sb.append("maxPokeballUsed=" + fMaxPokeball.getText());

    File settingsDataFile = new File(
      "jPokéBotResources/settingsPokemonCatch.txt"
    );

    FileWriter fw;
    try {
      fw = new FileWriter(settingsDataFile.getAbsoluteFile());
      BufferedWriter bw = new BufferedWriter(fw);
      bw.write(sb.toString());
      bw.close();
    } catch (IOException e) {
      e.printStackTrace();
    }
  }

  private void savePokemonTransferSettings() {
    StringBuilder sb = new StringBuilder();
    sb.append(
      "jPokéBot - POKEMON TRANSFER" +
      System.lineSeparator() +
      System.lineSeparator()
    );
    sb.append(
      "active=" + cActiveTransfer.isSelected() + System.lineSeparator()
    );
    sb.append("keepMinCP=" + cMinCP.isSelected() + System.lineSeparator());
    sb.append("keepMinIV=" + cMinIV.isSelected() + System.lineSeparator());
    sb.append("minCP=" + fMinCP.getText() + System.lineSeparator());
    sb.append("minIV=" + fMinIV.getText() + System.lineSeparator());
    sb.append(
      "maxDuplicate=" + fMaxDuplicate.getText() + System.lineSeparator()
    );
    sb.append(
      "keepLegendaries=" + cLegendary.isSelected() + System.lineSeparator()
    );
    sb.append(
      "keepPerfectMoves=" + cPerfectMoves.isSelected() + System.lineSeparator()
    );
    sb.append(
      "keepFavorites=" + cFavorite.isSelected() + System.lineSeparator()
    );
    sb.append(
      "activeSmartTransfer=" +
      cActiveSmartTransfer.isSelected() +
      System.lineSeparator()
    );
    sb.append("priority=" + prioritySlider.getValue() + System.lineSeparator());
    sb.append("minAverage=" + fMinAverage.getText());
    File settingsDataFile = new File("jPokéBotResources/settingsTransfer.txt");

    FileWriter fw;
    try {
      fw = new FileWriter(settingsDataFile.getAbsoluteFile());
      BufferedWriter bw = new BufferedWriter(fw);
      bw.write(sb.toString());
      bw.close();
    } catch (IOException e) {
      e.printStackTrace();
    }
  }

  private void savePokemonRenameSettings() {
    StringBuilder sb = new StringBuilder();
    sb.append(
      "jPokéBot - POKEMON RENAME" +
      System.lineSeparator() +
      System.lineSeparator()
    );
    sb.append("active=" + cActiveRename.isSelected() + System.lineSeparator());
    sb.append("renameIV=" + cRenameIV.isSelected() + System.lineSeparator());
    sb.append("renamePerfectMoves=" + cRenamePerfectMoves.isSelected());

    File settingsDataFile = new File("jPokéBotResources/settingsRename.txt");

    FileWriter fw;
    try {
      fw = new FileWriter(settingsDataFile.getAbsoluteFile());
      BufferedWriter bw = new BufferedWriter(fw);
      bw.write(sb.toString());
      bw.close();
    } catch (IOException e) {
      e.printStackTrace();
    }
  }

  private void saveRecycleItemsSettings() {
    StringBuilder sb = new StringBuilder();
    sb.append(
      "jPokéBot - ITEM RECYCLE SETTINGS" +
      System.lineSeparator() +
      System.lineSeparator()
    );
    sb.append("active=");
    if (cActiveRecycle.isSelected()) sb.append(
      "true" + System.lineSeparator()
    ); else sb.append("false" + System.lineSeparator());
    sb.append("recycleWhenFull=");
    if (cRecycleWhenFull.isSelected()) sb.append(
      "true" + System.lineSeparator()
    ); else sb.append("false" + System.lineSeparator());
    sb.append("keepMasterball=");
    if (cKeepMasterball.isSelected()) sb.append(
      "true" + System.lineSeparator()
    ); else sb.append("false" + System.lineSeparator());
    sb.append("keepIncense=");
    if (cKeepIncense.isSelected()) sb.append(
      "true" + System.lineSeparator()
    ); else sb.append("false" + System.lineSeparator());
    sb.append("keepTroyDisk=");
    if (cKeepTroyDisk.isSelected()) sb.append(
      "true" + System.lineSeparator()
    ); else sb.append("false" + System.lineSeparator());
    sb.append("keepLuckyEgg=");
    if (cKeepLuckyEgg.isSelected()) sb.append(
      "true" + System.lineSeparator()
    ); else sb.append("false" + System.lineSeparator());
    sb.append("pokeball=" + fPokeball.getText() + System.lineSeparator());
    sb.append("megaball=" + fMegaball.getText() + System.lineSeparator());
    sb.append("ultraball=" + fUltraball.getText() + System.lineSeparator());
    sb.append("masterball=");
    if (cKeepMasterball.isSelected()) sb.append(
      "infinity" + System.lineSeparator()
    ); else sb.append(fMasterball.getText() + System.lineSeparator());
    sb.append("potion=" + fPotion.getText() + System.lineSeparator());
    sb.append("superpotion=" + fSuperPotion.getText() + System.lineSeparator());
    sb.append("hyperpotion=" + fHyperPotion.getText() + System.lineSeparator());
    sb.append("maxpotion=" + fMaxPotion.getText() + System.lineSeparator());
    sb.append("revive=" + fRevive.getText() + System.lineSeparator());
    sb.append("maxrevive=" + fMaxRevive.getText() + System.lineSeparator());
    sb.append("razzberry=" + fRazzberry.getText() + System.lineSeparator());
    sb.append("luckyegg=");
    if (cKeepLuckyEgg.isSelected()) sb.append(
      "infinity" + System.lineSeparator()
    ); else sb.append(fLuckyEgg.getText() + System.lineSeparator());
    sb.append("troydisk=");
    if (cKeepTroyDisk.isSelected()) sb.append(
      "infinity" + System.lineSeparator()
    ); else sb.append(fTroyDisk.getText() + System.lineSeparator());
    sb.append("incense=");
    if (cKeepIncense.isSelected()) sb.append(
      "infinity" + System.lineSeparator()
    ); else sb.append(fIncense.getText() + System.lineSeparator());
    sb.append(
      "defaultConfig=" +
      chooseDefaultRecycle.getItemAt(chooseDefaultRecycle.getSelectedIndex()) +
      System.lineSeparator()
    );
    sb.append("autoUpdate=");
    if (autoUpdate.isSelected()) sb.append(
      "true" + System.lineSeparator()
    ); else sb.append("false" + System.lineSeparator());
    sb.append("firstStart=false");

    File settingsDataFile = new File(
      "jPokéBotResources/settingsItemRecycle.txt"
    );

    FileWriter fw;
    try {
      fw = new FileWriter(settingsDataFile.getAbsoluteFile());
      BufferedWriter bw = new BufferedWriter(fw);
      bw.write(sb.toString());
      bw.close();
    } catch (IOException e) {
      e.printStackTrace();
    }
  }

  protected void setDefaultRecycle(PokemonGo go) {
    fMasterball.setText("∞");
    fMasterball.setEnabled(false);
    cKeepMasterball.setSelected(true);

    fIncense.setText("∞");
    fIncense.setEnabled(false);
    cKeepIncense.setSelected(true);

    fTroyDisk.setText("∞");
    fTroyDisk.setEnabled(false);
    cKeepTroyDisk.setSelected(true);

    fLuckyEgg.setText("∞");
    fLuckyEgg.setEnabled(false);
    cKeepLuckyEgg.setSelected(true);

    int level = go.getPlayerProfile().getStats().getLevel();
    int maxStorage =
      go.getPlayerProfile().getPlayerData().getMaxItemStorage() -
      go
        .getInventories()
        .getItemBag()
        .getItem(ItemId.ITEM_INCUBATOR_BASIC)
        .getCount() -
      go
        .getInventories()
        .getItemBag()
        .getItem(ItemId.ITEM_INCUBATOR_BASIC_UNLIMITED)
        .getCount();
    int maxCatcherItems;
    int maxFighterItems;
    HashMap<String, Integer> config = new HashMap<String, Integer>();
    config.put("pokeball", 0);
    config.put("megaball", 0);
    config.put("ultraball", 0);
    config.put("masterball", 0);
    config.put("potion", 0);
    config.put("superpotion", 0);
    config.put("hyperpotion", 0);
    config.put("maxpotion", 0);
    config.put("revive", 0);
    config.put("maxrevive", 0);
    config.put("razzberry", 0);
    config.put("incense", 0);
    config.put("troydisk", 0);
    config.put("luckyegg", 0);
    if (recycleType.equals("Balanced")) {
      maxCatcherItems = maxStorage / 2;
      maxFighterItems = maxStorage / 2;
    } else if (recycleType.equals("Pokémon Catcher")) {
      maxCatcherItems = (maxStorage * 4) / 5;
      maxFighterItems = (maxStorage * 1) / 5;
    } else if (recycleType.equals("Gym Fighter")) {
      maxFighterItems = (maxStorage * 4) / 5;
      maxCatcherItems = (maxStorage * 1) / 5;
    } else if (recycleType.equals("Custom")) {
      maxFighterItems = 0;
      maxCatcherItems = 0;
      maxStorage = 0;
    } else {
      maxCatcherItems = maxStorage / 2;
      maxFighterItems = maxStorage / 2;
    }

    if (level < 5) {
      config.put("pokeball", maxStorage);
    } else if (level < 8) {
      config.put("pokeball", maxCatcherItems);
      config.put("potion", maxFighterItems / 2);
      config.put("revive", maxFighterItems / 2);
    } else if (level < 10) {
      config.put("pokeball", (maxCatcherItems * 4) / 5);
      config.put("razzberry", (maxCatcherItems * 1) / 5);
      config.put("potion", maxFighterItems / 2);
      config.put("revive", maxFighterItems / 2);
    } else if (level < 12) {
      config.put("pokeball", (maxCatcherItems * 4) / 5);
      config.put("razzberry", (maxCatcherItems * 1) / 5);
      config.put("potion", ((maxFighterItems / 2) * 1) / 4);
      config.put("superpotion", ((maxFighterItems / 2) * 3) / 4);
      config.put("revive", maxFighterItems / 2);
    } else if (level < 15) {
      config.put("pokeball", (((maxCatcherItems * 4) / 5) * 1) / 4);
      config.put("megaball", (((maxCatcherItems * 4) / 5) * 3) / 4);
      config.put("razzberry", (maxCatcherItems * 1) / 5);
      config.put("potion", ((maxFighterItems / 2) * 1) / 4);
      config.put("superpotion", ((maxFighterItems / 2) * 3) / 4);
      config.put("revive", maxFighterItems / 2);
    } else if (level < 20) {
      config.put("pokeball", (((maxCatcherItems * 4) / 5) * 1) / 4);
      config.put("megaball", (((maxCatcherItems * 4) / 5) * 3) / 4);
      config.put("razzberry", (maxCatcherItems * 1) / 5);
      config.put("potion", ((maxFighterItems / 2) * 1) / 10);
      config.put("superpotion", ((maxFighterItems / 2) * 3) / 10);
      config.put("hyperpotion", ((maxFighterItems / 2) * 6) / 10);
      config.put("revive", maxFighterItems / 2);
    } else if (level < 25) {
      config.put("pokeball", (((maxCatcherItems * 4) / 5) * 1) / 10);
      config.put("megaball", (((maxCatcherItems * 4) / 5) * 3) / 10);
      config.put("ultraball", (((maxCatcherItems * 4) / 5) * 6) / 10);
      config.put("razzberry", (maxCatcherItems * 1) / 5);
      config.put("potion", ((maxFighterItems / 2) * 1) / 10);
      config.put("superpotion", ((maxFighterItems / 2) * 3) / 10);
      config.put("hyperpotion", ((maxFighterItems / 2) * 6) / 10);
      config.put("revive", maxFighterItems / 2);
    } else if (level < 30) {
      config.put("pokeball", (((maxCatcherItems * 4) / 5) * 1) / 10);
      config.put("megaball", (((maxCatcherItems * 4) / 5) * 3) / 10);
      config.put("ultraball", (((maxCatcherItems * 4) / 5) * 6) / 10);
      config.put("razzberry", (maxCatcherItems * 1) / 5);
      config.put("potion", 0);
      config.put("superpotion", ((maxFighterItems / 2) * 1) / 10);
      config.put("hyperpotion", ((maxFighterItems / 2) * 3) / 10);
      config.put("maxpotion", ((maxFighterItems / 2) * 6) / 10);
      config.put("revive", maxFighterItems / 2);
    } else if (level >= 30) {
      config.put("pokeball", (((maxCatcherItems * 4) / 5) * 1) / 10);
      config.put("megaball", (((maxCatcherItems * 4) / 5) * 3) / 10);
      config.put("ultraball", (((maxCatcherItems * 4) / 5) * 6) / 10);
      config.put("razzberry", (maxCatcherItems * 1) / 5);
      config.put("potion", 0);
      config.put("superpotion", ((maxFighterItems / 2) * 1) / 10);
      config.put("hyperpotion", ((maxFighterItems / 2) * 3) / 10);
      config.put("maxpotion", ((maxFighterItems / 2) * 6) / 10);
      config.put("revive", ((maxFighterItems / 2) * 1) / 5);
      config.put("maxrevive", ((maxFighterItems / 2) * 4) / 5);
    }

    fPokeball.setText("" + config.get("pokeball"));
    fMegaball.setText("" + config.get("megaball"));
    fUltraball.setText("" + config.get("ultraball"));
    fRazzberry.setText("" + config.get("razzberry"));
    fPotion.setText("" + config.get("potion"));
    fSuperPotion.setText("" + config.get("superpotion"));
    fHyperPotion.setText("" + config.get("hyperpotion"));
    fMaxPotion.setText("" + config.get("maxpotion"));
    fRevive.setText("" + config.get("revive"));
    fMaxRevive.setText("" + config.get("maxrevive"));

    chooseDefaultRecycle.setSelectedItem(recycleType);

    if (recycleType.equals("Custom")) {
      autoUpdate.setSelected(false);
      autoUpdate.setEnabled(false);
    } else {
      autoUpdate.setSelected(true);
      autoUpdate.setEnabled(true);
    }
  }

  private void changeToCustom() {
    refreshItemsCount();
    chooseDefaultRecycle.setSelectedItem("Custom");
    autoUpdate.setSelected(false);
    autoUpdate.setEnabled(false);
  }

  protected void refreshItemsCount() {
    int count = 0;
    errorRecycle = false;
    try {
      count += Integer.parseUnsignedInt(fPokeball.getText());
      count += Integer.parseUnsignedInt(fMegaball.getText());
      count += Integer.parseUnsignedInt(fUltraball.getText());
      if (fMasterball.isEnabled()) count +=
        Integer.parseUnsignedInt(fMasterball.getText());
      if (fLuckyEgg.isEnabled()) count +=
        Integer.parseUnsignedInt(fLuckyEgg.getText());
      if (fIncense.isEnabled()) count +=
        Integer.parseUnsignedInt(fIncense.getText());
      if (fTroyDisk.isEnabled()) count +=
        Integer.parseUnsignedInt(fTroyDisk.getText());
      count += Integer.parseUnsignedInt(fRazzberry.getText());
      count += Integer.parseUnsignedInt(fPotion.getText());
      count += Integer.parseUnsignedInt(fSuperPotion.getText());
      count += Integer.parseUnsignedInt(fHyperPotion.getText());
      count += Integer.parseUnsignedInt(fMaxPotion.getText());
      count += Integer.parseUnsignedInt(fRevive.getText());
      count += Integer.parseUnsignedInt(fMaxRevive.getText());
      count += Integer.parseUnsignedInt(fBasicIncubator.getText());
      count += Integer.parseUnsignedInt(fUnlimitedBasicIncubator.getText());
    } catch (NumberFormatException e) {
      textBagInputError.setText("Wrong input!");
      fCurrentConfig.setText("?");
      errorRecycle = true;
      settingsError("RECYCLE");
    }
    if (!errorRecycle) {
      if (count > go.getPlayerProfile().getPlayerData().getMaxItemStorage()) {
        textBagInputError.setText("Bag size exceeded!");
        fCurrentConfig.setText("" + count);
      } else {
        fCurrentConfig.setText("" + count);
        textBagInputError.setText("");
        checkTotalSettingsError();
      }
    }
  }

  protected void enablePokemonCatchButtons() {
    fTimeOutCatch.setEnabled(true);
    cUseMasterballOnLegendary.setEnabled(true);
    bUsePokeball.setEnabled(true);
    if (bUsePokeball.getSelectedIndex() == 2) bDefaultPokeball.setEnabled(
      true
    ); else bDefaultPokeball.setEnabled(false);
    cLimitPokeball.setEnabled(true);
    if (cLimitPokeball.isSelected()) fMaxPokeball.setEnabled(
      true
    ); else fMaxPokeball.setEnabled(false);
    cUseBerry.setEnabled(true);
    if (cUseBerry.isSelected()) {
      cLimitBerry.setEnabled(true);
      if (cLimitBerry.isSelected()) {
        fMaxBerry.setEnabled(true);
      }
    } else {
      cLimitBerry.setEnabled(false);
      fMaxBerry.setEnabled(false);
    }
  }

  protected void disablePokemonCatchButtons() {
    fTimeOutCatch.setEnabled(false);
    cUseMasterballOnLegendary.setEnabled(false);
    bUsePokeball.setEnabled(false);
    bDefaultPokeball.setEnabled(false);
    cLimitPokeball.setEnabled(false);
    fMaxPokeball.setEnabled(false);
    cUseBerry.setEnabled(false);
    cLimitBerry.setEnabled(false);
    fMaxBerry.setEnabled(false);
  }

  protected void enablePokemonTransferButtons() {
    cLegendary.setEnabled(true);
    cFavorite.setEnabled(true);
    cPerfectMoves.setEnabled(true);
    cMinCP.setEnabled(true);
    cMinIV.setEnabled(true);
    fMaxDuplicate.setEnabled(true);
    cActiveSmartTransfer.setEnabled(true);
    if (cMinCP.isSelected()) fMinCP.setEnabled(true); else fMinCP.setEnabled(
      false
    );
    if (cMinIV.isSelected()) fMinIV.setEnabled(true); else fMinIV.setEnabled(
      false
    );
    if (cActiveSmartTransfer.isSelected()) {
      if (prioritySlider.getValue() != 50) balancePriority.setEnabled(true);
      prioritySlider.setEnabled(true);
      fMinAverage.setEnabled(true);
    } else {
      balancePriority.setEnabled(false);
      prioritySlider.setEnabled(false);
      fMinAverage.setEnabled(false);
    }
  }

  protected void disablePokemonTransferButtons() {
    cMinCP.setEnabled(false);
    cMinIV.setEnabled(false);
    fMinCP.setEnabled(false);
    fMinIV.setEnabled(false);
    fMaxDuplicate.setEnabled(false);
    cLegendary.setEnabled(false);
    cFavorite.setEnabled(false);
    cPerfectMoves.setEnabled(false);
    cActiveSmartTransfer.setEnabled(false);
    balancePriority.setEnabled(false);
    prioritySlider.setEnabled(false);
    fMinAverage.setEnabled(false);
  }

  protected void enablePokemonRenameButtons() {
    cRenameIV.setEnabled(true);
    cRenamePerfectMoves.setEnabled(true);
  }

  protected void disablePokemonRenameButtons() {
    cRenameIV.setEnabled(false);
    cRenamePerfectMoves.setEnabled(false);
  }

  protected void enableItemRecycleButtons() {
    cRecycleWhenFull.setEnabled(true);
    cKeepIncense.setEnabled(true);
    cKeepMasterball.setEnabled(true);
    cKeepLuckyEgg.setEnabled(true);
    cKeepTroyDisk.setEnabled(true);
    fPotion.setEnabled(true);
    fSuperPotion.setEnabled(true);
    fHyperPotion.setEnabled(true);
    fMaxPotion.setEnabled(true);
    fRevive.setEnabled(true);
    fMaxRevive.setEnabled(true);
    fPokeball.setEnabled(true);
    fMegaball.setEnabled(true);
    fUltraball.setEnabled(true);
    fRazzberry.setEnabled(true);
    defaultRecycle.setEnabled(true);
    chooseDefaultRecycle.setEnabled(true);
    fCurrentConfig.setEnabled(true);
    autoUpdate.setEnabled(true);
    if (cKeepMasterball.isSelected()) {
      fMasterball.setEnabled(false);
      fMasterball.setText("∞");
    } else {
      fMasterball.setEnabled(true);
      fMasterball.setText("0");
    }
    if (cKeepLuckyEgg.isSelected()) {
      fLuckyEgg.setEnabled(false);
      fLuckyEgg.setText("∞");
    } else {
      fLuckyEgg.setEnabled(true);
      fLuckyEgg.setText("0");
    }
    if (cKeepIncense.isSelected()) {
      fIncense.setEnabled(false);
      fIncense.setText("∞");
    } else {
      fIncense.setEnabled(true);
      fIncense.setText("0");
    }
    if (cKeepTroyDisk.isSelected()) {
      fTroyDisk.setEnabled(false);
      fTroyDisk.setText("∞");
    } else {
      fTroyDisk.setEnabled(true);
      fTroyDisk.setText("0");
    }
  }

  protected void disableItemRecycleButtons() {
    cRecycleWhenFull.setEnabled(false);
    cKeepIncense.setEnabled(false);
    cKeepMasterball.setEnabled(false);
    cKeepLuckyEgg.setEnabled(false);
    cKeepTroyDisk.setEnabled(false);
    fPotion.setEnabled(false);
    fSuperPotion.setEnabled(false);
    fHyperPotion.setEnabled(false);
    fMaxPotion.setEnabled(false);
    fRevive.setEnabled(false);
    fMaxRevive.setEnabled(false);
    fPokeball.setEnabled(false);
    fMegaball.setEnabled(false);
    fUltraball.setEnabled(false);
    fMasterball.setEnabled(false);
    defaultRecycle.setEnabled(false);
    chooseDefaultRecycle.setEnabled(false);
    fMasterball.setText("0");
    fLuckyEgg.setEnabled(false);
    fLuckyEgg.setText("0");
    fIncense.setEnabled(false);
    fIncense.setText("0");
    fTroyDisk.setEnabled(false);
    fTroyDisk.setText("0");
    fRazzberry.setEnabled(false);
    fCurrentConfig.setEnabled(false);
    autoUpdate.setEnabled(false);
  }
}

package app;

import com.pokegoapi.api.PokemonGo;
import com.pokegoapi.api.gym.Battle;
import com.pokegoapi.api.gym.Gym;
import com.pokegoapi.api.pokemon.Pokemon;
import com.pokegoapi.exceptions.LoginFailedException;
import com.pokegoapi.exceptions.RemoteServerException;
import java.util.List;

public class GymBuffer {

  public static void main(String[] args)
    throws LoginFailedException, RemoteServerException {
    PokemonGo go = Bot.connect("username", "password");
    go.setLocation(-33.8482439, 150.9319747, 17);
    List<Gym> allGym = go.getMap().getGyms();
    for (Gym g : allGym) System.out.println(
      "Gym: " +
      g.getName() +
      " " +
      g.getOwnedByTeam().name() +
      " " +
      g.getPoints()
    );
    Gym gym = allGym.get(0);
    List<Pokemon> pokebank = go.getInventories().getPokebank().getPokemons();
    int maxCP = 0;
    Pokemon pokemonMaxCP = null;
    for (Pokemon pokemon : pokebank) {
      if (pokemon.getCp() > maxCP) {
        pokemonMaxCP = pokemon;
        maxCP = pokemon.getCp();
      }
    }
    System.out.println(
      "Pokemon max CP: " +
      pokemonMaxCP.getPokemonId().name() +
      " [CP " +
      maxCP +
      "]"
    );
    Pokemon[] team = { pokemonMaxCP };
    go.setLocation(gym.getLatitude(), gym.getLongitude(), 17);
    System.out.println(gym.battle(team).start().name());
    System.out.println(
      "Gym: " +
      gym.getName() +
      " " +
      gym.getOwnedByTeam().name() +
      " " +
      gym.getPoints()
    );
  }
}

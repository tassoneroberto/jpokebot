package app;

import com.pokegoapi.api.PokemonGo;
import com.pokegoapi.exceptions.AsyncPokemonGoException;
import com.pokegoapi.exceptions.LoginFailedException;
import com.pokegoapi.exceptions.RemoteServerException;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.HashMap;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

public class FrameLogin extends JFrame {

  private static final long serialVersionUID = 1L;

  private static HashMap<String, double[]> defaultCoordinates = new HashMap<String, double[]>();
  private JPanel container;
  private JLabel textEmail;
  private JLabel textPassword;
  private JLabel textLatitude;
  private JLabel textLongitude;
  private JLabel loginMessage;
  private JTextField email;
  private JPasswordField password;
  private JTextField latitude;
  private JTextField longitude;
  private JButton login;
  private JButton setCoords;
  private JComboBox<String> defaultCoords;
  private JCheckBox saveData;
  private boolean isAsyncError = true;
  private boolean isWrongInputError = false;

  public FrameLogin() {
    this.setTitle("jPokéBot v" + Bot.VERSION);
    int width = 320;
    int height = 270;
    this.setSize(width, height);
    this.setLocationRelativeTo(null);
    this.setLayout(null);
    this.setResizable(false);
    this.setDefaultCloseOperation(EXIT_ON_CLOSE);

    container = new JPanel(null);
    this.add(container);
    container.setBounds(0, 0, width, height);

    textEmail = new JLabel("Email");
    email = new JTextField();
    container.add(email);
    container.add(textEmail);
    textEmail.setBounds(10, 10, 300, 20);
    email.setBounds(10, 30, 300, 20);

    textPassword = new JLabel("Password");
    password = new JPasswordField();
    container.add(password);
    container.add(textPassword);
    textPassword.setBounds(10, 50, 300, 20);
    password.setBounds(10, 70, 300, 20);

    textLatitude = new JLabel("Latitude");
    latitude = new JTextField("");
    container.add(latitude);
    container.add(textLatitude);
    textLatitude.setBounds(10, 90, 150, 20);
    latitude.setBounds(10, 110, 150, 20);

    textLongitude = new JLabel("Longitude");
    longitude = new JTextField("");
    container.add(longitude);
    container.add(textLongitude);
    textLongitude.setBounds(160, 90, 150, 20);
    longitude.setBounds(160, 110, 150, 20);

    setCoords = new JButton("Set coordinates");
    container.add(setCoords);
    setCoords.setBounds(10, 140, 150, 20);

    defaultCoords = new JComboBox<String>();
    loadDefaultCoordinates();
    container.add(defaultCoords);
    defaultCoords.setBounds(160, 135, 150, 30);

    login = new JButton("Login");
    container.add(login);
    login.setBounds(10, 180, 200, 20);

    saveData = new JCheckBox("Save data");
    container.add(saveData);
    saveData.setSelected(true);
    saveData.setBounds(220, 177, 100, 25);

    loginMessage = new JLabel("Enter your login data to connect.");
    container.add(loginMessage);
    loginMessage.setBounds(10, 210, 300, 20);

    setCoords.addActionListener(
      new ActionListener() {
        public void actionPerformed(ActionEvent e) {
          double[] coords = defaultCoordinates.get(
            defaultCoords.getSelectedItem()
          );
          latitude.setText("" + coords[0]);
          longitude.setText("" + coords[1]);
        }
      }
    );

    login.addActionListener(
      new ActionListener() {
        public void actionPerformed(ActionEvent e) {
          login();
        }
      }
    );

    email.addKeyListener(
      new KeyAdapter() {
        public void keyPressed(KeyEvent e) {
          int key = e.getKeyCode();
          if (key == KeyEvent.VK_ENTER) {
            login();
          }
        }
      }
    );

    password.addKeyListener(
      new KeyAdapter() {
        public void keyPressed(KeyEvent e) {
          int key = e.getKeyCode();
          if (key == KeyEvent.VK_ENTER) {
            login();
          }
        }
      }
    );

    latitude.addKeyListener(
      new KeyAdapter() {
        public void keyPressed(KeyEvent e) {
          int key = e.getKeyCode();
          if (key == KeyEvent.VK_ENTER) {
            login();
          }
        }
      }
    );

    longitude.addKeyListener(
      new KeyAdapter() {
        public void keyPressed(KeyEvent e) {
          int key = e.getKeyCode();
          if (key == KeyEvent.VK_ENTER) {
            login();
          }
        }
      }
    );

    File dir = new File("jPokéBotResources/");
    if (!dir.exists()) {
      dir.mkdirs();
    }

    File movesetFile = new File("jPokéBotResources/moveset.txt");
    if (!movesetFile.exists()) {
      try {
        movesetFile.createNewFile();
        FileWriter fw = new FileWriter(movesetFile.getAbsoluteFile());
        BufferedWriter bw = new BufferedWriter(fw);
        bw.write(getMoveset());
        bw.close();
      } catch (IOException e1) {
        e1.printStackTrace();
      }
    }

    File changelogFile = new File("jPokéBotResources/changelog.txt");
    if (!changelogFile.exists()) {
      try {
        changelogFile.createNewFile();
        FileWriter fw = new FileWriter(changelogFile.getAbsoluteFile());
        BufferedWriter bw = new BufferedWriter(fw);
        bw.write(getChangelog());
        bw.close();
      } catch (IOException e1) {
        e1.printStackTrace();
      }
    }

    File loginDataFile = new File("jPokéBotResources/loginData.txt");
    if (!loginDataFile.exists()) {
      try {
        loginDataFile.createNewFile();
        FileWriter fw = new FileWriter(loginDataFile.getAbsoluteFile());
        BufferedWriter bw = new BufferedWriter(fw);
        bw.write(getDefaultLogin());
        bw.close();
      } catch (IOException e1) {
        e1.printStackTrace();
      }
    } else {
      loadLoginData();
    }

    File defaultRecycleFile = new File(
      "jPokéBotResources/settingsItemRecycle.txt"
    );
    if (!defaultRecycleFile.exists()) {
      try {
        defaultRecycleFile.createNewFile();
        FileWriter fw = new FileWriter(defaultRecycleFile.getAbsoluteFile());
        BufferedWriter bw = new BufferedWriter(fw);
        bw.write(getDefaultSettingsRecycle());
        bw.close();
      } catch (IOException e1) {
        e1.printStackTrace();
      }
    }

    File defaultGeneralFile = new File("jPokéBotResources/settingsGeneral.txt");
    if (!defaultGeneralFile.exists()) {
      try {
        defaultGeneralFile.createNewFile();
        FileWriter fw = new FileWriter(defaultGeneralFile.getAbsoluteFile());
        BufferedWriter bw = new BufferedWriter(fw);
        bw.write(getDefaultGeneralSettings());
        bw.close();
      } catch (IOException e1) {
        e1.printStackTrace();
      }
    }

    File defaultPokemonCatchFile = new File(
      "jPokéBotResources/settingsPokemonCatch.txt"
    );
    if (!defaultPokemonCatchFile.exists()) {
      try {
        defaultPokemonCatchFile.createNewFile();
        FileWriter fw = new FileWriter(
          defaultPokemonCatchFile.getAbsoluteFile()
        );
        BufferedWriter bw = new BufferedWriter(fw);
        bw.write(getDefaultSettingsPokemonCatch());
        bw.close();
      } catch (IOException e1) {
        e1.printStackTrace();
      }
    }

    File defaultTransferFile = new File(
      "jPokéBotResources/settingsTransfer.txt"
    );
    if (!defaultTransferFile.exists()) {
      try {
        defaultTransferFile.createNewFile();
        FileWriter fw = new FileWriter(defaultTransferFile.getAbsoluteFile());
        BufferedWriter bw = new BufferedWriter(fw);
        bw.write(getDefaultSettingsTransfer());
        bw.close();
      } catch (IOException e1) {
        e1.printStackTrace();
      }
    }

    File defaultRenameFile = new File("jPokéBotResources/settingsRename.txt");
    if (!defaultRenameFile.exists()) {
      try {
        defaultTransferFile.createNewFile();
        FileWriter fw = new FileWriter(defaultRenameFile.getAbsoluteFile());
        BufferedWriter bw = new BufferedWriter(fw);
        bw.write(getDefaultSettingsRename());
        bw.close();
      } catch (IOException e1) {
        e1.printStackTrace();
      }
    }
  }

  private void loadDefaultCoordinates() {
    double[] sidneyCoords = { -33.86302591709663, 151.2098517268896 };
    defaultCoordinates.put("[AU] Sidney", sidneyCoords);

    double[] hongKongCoords = { 22.285661566028704, 114.15020227432251 };
    defaultCoordinates.put("[CN] Hong Kong", hongKongCoords);

    double[] tokyoCoords = { 35.684895044528794, 139.70996975898743 };
    defaultCoordinates.put("[JP] Tokyo", tokyoCoords);

    double[] newYorkCoords = { 40.7711329, -73.9741874 };
    defaultCoordinates.put("[US] New York", newYorkCoords);

    double[] californiaCoords = { 34.0092419, -118.49760370000001 };
    defaultCoordinates.put("[US] California", californiaCoords);

    double[] berlinCoords = { 52.53702300, 13.20301100 };
    defaultCoordinates.put("[EU] Berlin", berlinCoords);

    double[] milanCoords = { 45.47210, 9.17722 };
    defaultCoordinates.put("[EU] Milan", milanCoords);

    // double[] cauloniaCoords = { 38.3422231444887, 16.46227106451988 };
    // defaultCoordinates.put("[EU] Caulonia", cauloniaCoords);

    for (String location : defaultCoordinates.keySet()) {
      defaultCoords.addItem(location);
    }
  }

  private String getDefaultLogin() {
    BufferedReader br = new BufferedReader(
      new InputStreamReader(
        getClass().getResourceAsStream("/jPokéBotResources/defaultLogin.txt")
      )
    );
    StringBuilder sb = new StringBuilder();
    String line;
    try {
      while ((line = br.readLine()) != null) {
        sb.append(line + System.lineSeparator());
      }
    } catch (IOException e) {
      e.printStackTrace();
    }
    return sb.toString();
  }

  private String getDefaultSettingsRecycle() {
    BufferedReader br = new BufferedReader(
      new InputStreamReader(
        getClass()
          .getResourceAsStream("/jPokéBotResources/settingsItemRecycle.txt")
      )
    );
    StringBuilder sb = new StringBuilder();
    String line;
    try {
      while ((line = br.readLine()) != null) {
        sb.append(line + System.lineSeparator());
      }
    } catch (IOException e) {
      e.printStackTrace();
    }
    return sb.toString();
  }

  private String getDefaultGeneralSettings() {
    BufferedReader br = new BufferedReader(
      new InputStreamReader(
        getClass().getResourceAsStream("/jPokéBotResources/settingsGeneral.txt")
      )
    );
    StringBuilder sb = new StringBuilder();
    String line;
    try {
      while ((line = br.readLine()) != null) {
        sb.append(line + System.lineSeparator());
      }
    } catch (IOException e) {
      e.printStackTrace();
    }
    return sb.toString();
  }

  private String getDefaultSettingsPokemonCatch() {
    BufferedReader br = new BufferedReader(
      new InputStreamReader(
        getClass()
          .getResourceAsStream("/jPokéBotResources/settingsPokemonCatch.txt")
      )
    );
    StringBuilder sb = new StringBuilder();
    String line;
    try {
      while ((line = br.readLine()) != null) {
        sb.append(line + System.lineSeparator());
      }
    } catch (IOException e) {
      e.printStackTrace();
    }
    return sb.toString();
  }

  private String getDefaultSettingsTransfer() {
    BufferedReader br = new BufferedReader(
      new InputStreamReader(
        getClass()
          .getResourceAsStream("/jPokéBotResources/settingsTransfer.txt")
      )
    );
    StringBuilder sb = new StringBuilder();
    String line;
    try {
      while ((line = br.readLine()) != null) {
        sb.append(line + System.lineSeparator());
      }
    } catch (IOException e) {
      e.printStackTrace();
    }
    return sb.toString();
  }

  private String getDefaultSettingsRename() {
    BufferedReader br = new BufferedReader(
      new InputStreamReader(
        getClass().getResourceAsStream("/jPokéBotResources/settingsRename.txt")
      )
    );
    StringBuilder sb = new StringBuilder();
    String line;
    try {
      while ((line = br.readLine()) != null) {
        sb.append(line + System.lineSeparator());
      }
    } catch (IOException e) {
      e.printStackTrace();
    }
    return sb.toString();
  }

  private String getChangelog() {
    BufferedReader br = new BufferedReader(
      new InputStreamReader(
        getClass().getResourceAsStream("/jPokéBotResources/changelog.txt")
      )
    );
    StringBuilder sb = new StringBuilder();
    String line;
    try {
      while ((line = br.readLine()) != null) {
        sb.append(line + System.lineSeparator());
      }
    } catch (IOException e) {
      e.printStackTrace();
    }
    return sb.toString();
  }

  private String getMoveset() {
    BufferedReader br = new BufferedReader(
      new InputStreamReader(
        getClass().getResourceAsStream("/jPokéBotResources/moveset.txt")
      )
    );
    StringBuilder sb = new StringBuilder();
    String line;
    try {
      while ((line = br.readLine()) != null) {
        sb.append(line + System.lineSeparator());
      }
    } catch (IOException e) {
      e.printStackTrace();
    }
    return sb.toString();
  }

  protected String checkLoginData() {
    if (
      email.getText().equals("") ||
      password.getPassword().toString().equals("") ||
      latitude.getText().equals("") ||
      longitude.getText().equals("")
    ) {
      return "Error: all fields are required.";
    }
    boolean coordinatesOK = true;
    try {
      Double.parseDouble(latitude.getText());
      Double.parseDouble(longitude.getText());
    } catch (NumberFormatException e) {
      coordinatesOK = false;
    }
    if (!coordinatesOK) {
      return "Error: check your coordinates.";
    }
    return "";
  }

  private void loadLoginData() {
    BufferedReader br = new BufferedReader(
      new InputStreamReader(
        getClass().getResourceAsStream("/jPokéBotResources/loginData.txt")
      )
    );
    String line;
    try {
      while ((line = br.readLine()) != null) {
        String[] info = line.split("=");
        if (info.length == 2 && !info[1].equals("")) {
          if (info[0].equals("email")) email.setText(info[1]); else if (
            info[0].equals("password")
          ) password.setText(info[1]); else if (
            info[0].equals("latitude")
          ) latitude.setText(info[1]); else if (
            info[0].equals("longitude")
          ) longitude.setText(info[1]); else if (
            info[0].equals("saveLoginData")
          ) {
            if (info[1].equals("true")) saveData.setSelected(true);
          }
        }
      }
    } catch (IOException e) {
      e.printStackTrace();
    }
  }

  protected void login() {
    isAsyncError = true;
    isWrongInputError = false;
    LoginLoader loader = new LoginLoader();
    disableButtons();
    loginMessage.setText("Connecting...");
    loader.start();
  }

  private void disableButtons() {
    login.setEnabled(false);
    email.setEnabled(false);
    password.setEnabled(false);
    latitude.setEnabled(false);
    longitude.setEnabled(false);
    setCoords.setEnabled(false);
    defaultCoords.setEnabled(false);
    saveData.setEnabled(false);
  }

  private void enableButtons() {
    login.setEnabled(true);
    email.setEnabled(true);
    password.setEnabled(true);
    latitude.setEnabled(true);
    longitude.setEnabled(true);
    setCoords.setEnabled(true);
    defaultCoords.setEnabled(true);
    saveData.setEnabled(true);
  }

  public class LoginLoader extends Thread {

    public void run() {
      while (isAsyncError && !isWrongInputError) {
        String loginDataError = checkLoginData();
        if (!loginDataError.equals("")) {
          loginMessage.setText(loginDataError);
          isWrongInputError = true;
        } else {
          isWrongInputError = false;
          isAsyncError = false;
          PokemonGo go = null;
          try {
            go =
              Bot.connect(email.getText(), new String(password.getPassword()));
          } catch (LoginFailedException e1) {
            loginMessage.setText("Wrong input data!");
            enableButtons();
            isWrongInputError = true;
          } catch (RemoteServerException e1) {
            loginMessage.setText("Server unreachable! Retrying...");
            isAsyncError = true;
          } catch (AsyncPokemonGoException e1) {
            loginMessage.setText("Async exception! Retrying...");
            isAsyncError = true;
          }
          if (!isAsyncError && !isWrongInputError) {
            if (saveData.isSelected()) saveLoginData();
            inzializeBot(
              go,
              Double.parseDouble(latitude.getText()),
              Double.parseDouble(longitude.getText())
            );
          }
        }
      }
    }
  }

  private void saveLoginData() {
    StringBuilder sb = new StringBuilder();
    sb.append(
      "jPokéBot - LOGIN DATA" + System.lineSeparator() + System.lineSeparator()
    );
    sb.append("email=" + email.getText() + System.lineSeparator());
    sb.append(
      "password=" + new String(password.getPassword()) + System.lineSeparator()
    );
    sb.append("latitude=" + latitude.getText() + System.lineSeparator());
    sb.append("longitude=" + longitude.getText() + System.lineSeparator());
    sb.append("saveLoginData=true");

    File loginDataFile = new File("jPokéBotResources/loginData.txt");

    FileWriter fw;
    try {
      fw = new FileWriter(loginDataFile.getAbsoluteFile());
      BufferedWriter bw = new BufferedWriter(fw);
      bw.write(sb.toString());
      bw.close();
    } catch (IOException e) {
      e.printStackTrace();
    }
  }

  protected void inzializeBot(PokemonGo go, double latitude, double longitude) {
    this.setVisible(false);
    FrameBot fb = new FrameBot(go, latitude, longitude);
    fb.setVisible(true);
  }

  public static void main(String[] args) {
    JFrame f = new FrameLogin();
    f.setVisible(true);
  }
}

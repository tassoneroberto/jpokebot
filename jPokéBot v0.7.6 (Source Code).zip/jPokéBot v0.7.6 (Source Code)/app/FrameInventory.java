package app;

import com.pokegoapi.api.PokemonGo;
import com.pokegoapi.exceptions.LoginFailedException;
import com.pokegoapi.exceptions.RemoteServerException;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JEditorPane;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.ScrollPaneConstants;

public class FrameInventory extends JFrame {

  private static final long serialVersionUID = 1L;

  private JPanel container;
  private JLabel textInventory;
  private JButton refresh;
  private JEditorPane display;
  private JScrollPane scroll;
  private PokemonGo go;
  private Bot bot;

  public FrameInventory(PokemonGo go) {
    this.go = go;
    bot = new Bot(go);
    this.setTitle("Inventory");
    int width = 300;
    int height = 550;
    this.setSize(width, height);
    this.setLocationRelativeTo(null);
    this.setLayout(null);
    this.setResizable(false);
    this.setDefaultCloseOperation(HIDE_ON_CLOSE);

    container = new JPanel(null);
    this.add(container);
    container.setBounds(0, 0, width, height);

    textInventory =
      new JLabel(
        "Count: " +
        go.getInventories().getItemBag().getItemsCount() +
        "/" +
        go.getPlayerProfile().getPlayerData().getMaxItemStorage()
      );
    container.add(textInventory);
    textInventory.setBounds(10, 10, 150, 20);

    display = new JEditorPane();
    display.setEditable(false);
    display.setContentType("text/html");
    scroll = new JScrollPane(display);
    scroll.setVerticalScrollBarPolicy(
      ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS
    );
    container.add(scroll);
    scroll.setBounds(10, 40, width - 20, height - 70);

    refresh = new JButton("Refresh");
    container.add(refresh);
    refresh.setBounds(width - 110, 10, 100, 20);
    refresh.addActionListener(
      new ActionListener() {
        public void actionPerformed(ActionEvent e) {
          refresh();
        }
      }
    );

    refresh();
  }

  public void refresh() {
    try {
      go.getInventories().updateInventories();
    } catch (LoginFailedException e1) {
      e1.printStackTrace();
    } catch (RemoteServerException e1) {
      e1.printStackTrace();
    }
    display.setText(bot.printInventory());
    textInventory.setText(
      "Count: " +
      go.getInventories().getItemBag().getItemsCount() +
      "/" +
      go.getPlayerProfile().getPlayerData().getMaxItemStorage()
    );
    display.setCaretPosition(0);
  }
}

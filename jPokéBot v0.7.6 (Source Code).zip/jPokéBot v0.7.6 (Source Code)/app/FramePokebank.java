package app;

import com.pokegoapi.api.PokemonGo;
import com.pokegoapi.exceptions.LoginFailedException;
import com.pokegoapi.exceptions.RemoteServerException;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JEditorPane;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JScrollPane;
import javax.swing.ScrollPaneConstants;

public class FramePokebank extends JFrame {

  private static final long serialVersionUID = 1L;

  private JPanel container;
  private JLabel textPokebank;
  private JLabel textSort;
  private JButton refresh;
  private JEditorPane display;
  private ButtonGroup sortByGroup;
  private JRadioButton cpButton;
  private JRadioButton ivButton;
  private JRadioButton nButton;
  private JRadioButton azButton;
  private Bot bot;
  private JScrollPane scroll;
  private PokemonGo go;

  public FramePokebank(PokemonGo go) {
    this.go = go;
    bot = new Bot(go);
    this.setTitle("Pokébank");
    int width = 700;
    int height = 600;
    this.setSize(width, height);
    this.setLocationRelativeTo(null);
    this.setLayout(null);
    this.setResizable(false);
    this.setDefaultCloseOperation(HIDE_ON_CLOSE);

    container = new JPanel(null);
    this.add(container);
    container.setBounds(0, 0, width, height);

    textSort = new JLabel("Sort by:");
    container.add(textSort);
    textSort.setBounds(10, 10, 50, 20);

    textPokebank =
      new JLabel(
        "Count: " +
        go.getInventories().getPokebank().getPokemons().size() +
        "/" +
        go.getPlayerProfile().getPlayerData().getMaxPokemonStorage()
      );
    container.add(textPokebank);
    textPokebank.setBounds(10, 30, 150, 20);

    sortByGroup = new ButtonGroup();
    cpButton = new JRadioButton("CP", true);
    ivButton = new JRadioButton("IV", false);
    nButton = new JRadioButton("#", false);
    azButton = new JRadioButton("AZ", false);
    sortByGroup.add(cpButton);
    sortByGroup.add(ivButton);
    sortByGroup.add(nButton);
    sortByGroup.add(azButton);
    container.add(cpButton);
    container.add(ivButton);
    container.add(nButton);
    container.add(azButton);
    cpButton.setBounds(60, 10, 50, 20);
    ivButton.setBounds(115, 10, 50, 20);
    nButton.setBounds(170, 10, 50, 20);
    azButton.setBounds(215, 10, 50, 20);

    display = new JEditorPane();
    display.setEditable(false);
    display.setContentType("text/html");
    scroll = new JScrollPane(display);
    scroll.setVerticalScrollBarPolicy(
      ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS
    );
    container.add(scroll);
    scroll.setBounds(10, 60, width - 20, height - 90);

    refresh = new JButton("Refresh");
    container.add(refresh);
    refresh.setBounds(width - 110, 10, 100, 20);
    refresh.addActionListener(
      new ActionListener() {
        public void actionPerformed(ActionEvent e) {
          refresh();
        }
      }
    );

    refresh();
  }

  public void refresh() {
    try {
      go.getInventories().updateInventories();
    } catch (LoginFailedException e1) {
      e1.printStackTrace();
    } catch (RemoteServerException e1) {
      e1.printStackTrace();
    }
    String sortBy;
    if (cpButton.isSelected()) sortBy = "cp"; else if (
      ivButton.isSelected()
    ) sortBy = "iv"; else if (azButton.isSelected()) sortBy = "az"; else if (
      nButton.isSelected()
    ) sortBy = "number"; else sortBy = "default";
    display.setText(bot.printPokebank(sortBy));
    textPokebank.setText(
      "Count: " +
      go.getInventories().getPokebank().getPokemons().size() +
      "/" +
      go.getPlayerProfile().getPlayerData().getMaxPokemonStorage()
    );
    display.setCaretPosition(0);
  }
}
